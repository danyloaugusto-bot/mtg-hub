# motor.py — funções comuns: montar versões, checar, contar, placar, previsibilidade.
import json,unicodedata,math,sys
sys.path.insert(0,'/home/claude/edgar/scripts')
from dados import D,EIXOS,PARES,CAMADAS
BASE='/home/claude/edgar/'
def norm(n): return unicodedata.normalize('NFKD',n).encode('ascii','ignore').decode().strip().lower()
LISTA=json.load(open(BASE+'lista_atual.json'))['cartas']
PETS={c['nome'] for c in LISTA if c['pet']}
def atual():
    L=[]
    for c in LISTA:
        L+= [c['nome']]*c['q']
    return L
def montar(base,pares):
    L=list(base)
    for sai,entra,*_ in pares:
        assert L.count(sai)>=1, ('sai ausente',sai)
        L.remove(sai); L.append(entra)
    return L
def checar(L,nome):
    assert len(L)==100,(nome,len(L))
    assert 'Edgar Markov' in L
    basic={'Plains','Swamp','Mountain'}
    for x in set(L):
        if x not in basic: assert L.count(x)==1,(nome,'repetida',x)
        assert x in D,(nome,'sem dados',x)
    for p in PETS: assert p in L,(nome,'pet cortado',p)
    for sai,entra,*_ in PARES: assert sai not in PETS,('pet na fila de corte',sai)
    return True
EDH=json.load(open(BASE+'edhrec.json'))
def inc(n):
    k=norm(n); e=EDH['edhrec'].get(k,{}).get('inc')
    return e
def stats(L):
    nc=[x for x in L if x!='Edgar Markov']
    lands=[x for x in nc if D[x]['tipo']=='L']
    non=[x for x in nc if D[x]['tipo']!='L']
    cmc=sum(D[x]['mv'] for x in non)/len(non)
    S={}
    S['terrenos']=len(lands)
    S['nao_terrenos']=len(non)
    S['cmc']=cmc
    S['vampiros']=sum(1 for x in nc if 'V' in D[x]['flags'])
    S['vamp_mv12']=sum(1 for x in nc if 'V' in D[x]['flags'] and D[x]['mv']<=2)
    S['vamp_mv1']=sum(1 for x in nc if 'V' in D[x]['flags'] and D[x]['mv']==1)
    S['lordes']=sum(1 for x in nc if 'L' in D[x]['flags'])
    S['tap']=sum(1 for x in lands if 'TAP' in D[x]['flags'])
    for e in EIXOS:
        S['n_'+e]=sum(1 for x in nc if D[x]['n'][e]>=2)
        S['soma_'+e]=sum(D[x]['n'][e] for x in nc)
    S['ramp_nao_terreno']=sum(1 for x in non if D[x]['n']['MAN']>=2)
    S['massa']=sum(1 for x in nc if ('US' in D[x]['flags'] or 'WP' in D[x]['flags']))
    S['unilateral']=sum(1 for x in nc if 'US' in D[x]['flags'])
    S['gc']=sorted(x for x in nc if 'GC' in D[x]['flags'])
    S['tiers']={t:sum(1 for x in nc if D[x]['tier']==t) for t in 'SABCD'}
    S['soma_notas']=sum(sum(D[x]['n'].values()) for x in nc)
    pc=5 if cmc<2 else 4 if cmc<3 else 3 if cmc<4 else 2 if cmc<5 else 1
    acel=min(90,math.floor((S['soma_MAN']/cmc)/0.5)*5)
    S['pts_cmc']=pc; S['pts_acel']=acel
    S['placar']=pc+acel+S['soma_notas']
    incs=[inc(x) for x in non]
    S['prev_media']=sum(i for i in incs if i is not None)/len(non)  # ausentes contam 0 (abaixo do corte)
    S['prev_50']=sum(1 for i in incs if i is not None and i>=50)
    S['prev_fora']=sum(1 for i in incs if i is None)
    return S

# dados.py — Edgar Markov (Danylo), 15/10/2026. Eixos: MAN CMP REM PRO EMI COR INV BAN (0 a 3).
# c(nome, tipo, mv, notas(8), tier, relev, flags, porque, pt)   tipo: L terreno, C criatura, O outro
EIXOS=['MAN','CMP','REM','PRO','EMI','COR','INV','BAN']
NOMES_EIXOS={'MAN':'Mana','CMP':'Compra e busca','REM':'Remoção','PRO':'Proteção','EMI':'Eminência','COR':'Coroação','INV':'Investida','BAN':'Banquete'}
D={}
def c(nome,tipo,mv,n,tier,rel,flags='',porque='',pt=None):
    assert len(n)==8, nome
    D[nome]=dict(nome=nome,tipo=tipo,mv=mv,n=dict(zip(EIXOS,n)),tier=tier,rel=rel,flags=set(flags.split()),porque=porque,pt=pt)
# ---------- comandante ----------
c("Edgar Markov",'C',6,(0,0,0,0,3,3,3,0),'S','INS','V PET CMD',"A eminência trabalha da zona de comando desde o turno 1; em campo, cada ataque coroa todos os Vampiros.",(4,4))
# ---------- lista atual: criaturas ----------
c("Baron Bertram Graywater",'C',4,(0,2,0,0,2,0,0,2),'A','ALT','V TK SAC',"A primeira ficha do turno gera outra; a saída de sacrifício troca ficha por carta.",(3,4))
c("Blood Artist",'C',2,(0,0,0,0,3,0,0,3),'A','ALT','V DR',"Vampiro de 2 que transforma bloqueio e limpeza em dreno; o plano B começa aqui.",(0,1))
c("Bloodline Keeper",'C',4,(0,0,0,0,3,3,1,0),'S','INS','V L TK',"Fábrica de 2/2 voadores; com cinco Vampiros vira lorde de +2/+2.",(3,3))
c("Bloodlord of Vaasgoth",'C',5,(0,0,0,0,1,1,0,0),'D','BAX','V',"Bloodthirst pede dano antes; você conjura antes do combate. Cinco manas por quase nada.",(3,3))
c("Bloodthirsty Conqueror",'C',5,(0,0,0,0,1,0,1,3),'A','ALT','V CBK',"Metade do combo com o Vito (Spellbook 314-6191); sozinho, 5/5 voador com toque mortífero.",(5,5))
c("Captivating Vampire",'C',3,(0,0,2,0,2,3,0,0),'S','INS','V L',"Lorde de 3 e, com cinco Vampiros desvirados, rouba uma criatura por turno.",(2,2))
c("Carmen, Cruel Skymarcher",'C',5,(0,0,0,0,1,1,1,2),'C','MÉD','V',"Cinco manas para crescer com sacrifícios; o Edgar já coroa a tribo inteira.",(2,2))
c("Cemetery Gatekeeper",'C',2,(0,0,0,0,3,0,1,0),'C','MÉD','V PET',"Vampiro de 2 para a eminência. Nunca exile carta de criatura: ele também queima você.",(2,1))
c("Clavileño, First of the Blessed",'C',3,(0,1,0,0,2,0,1,1),'B','ALT','V PET TK',"Cada ataque prepara um Demônio que, ao morrer, compra e deixa um 4/3 voador.",(2,2))
c("Cordial Vampire",'C',2,(0,0,0,0,3,3,0,2),'A','ALT','V CT',"Cada morte, de qualquer lado da mesa, é +1/+1 em todos os Vampiros.",(1,1))
c("Cruel Celebrant",'C',2,(0,0,0,0,3,0,0,3),'A','ALT','V DR',"Cada morte sua drena cada oponente; mesa larga vira relógio.",(1,2))
c("Drana and Linvala",'C',4,(0,0,1,0,1,0,1,0),'B','MÉD','V',"Voadora que desliga as habilidades ativadas das criaturas deles; boa, mas fora da conta.",(3,4))
c("Dusk Legion Sergeant",'C',2,(0,0,0,1,3,0,0,1),'D','BAX','V',"Persist só em Vampiro que não é ficha, e o deck é feito de fichas.",(2,1))
c("Edgar, Charmed Groom",'C',4,(0,0,0,0,1,3,0,1),'A','ALT','V L TK',"Lorde que, ao morrer, vira o caixão que fabrica Vampiros.",(4,4))
c("Elenda, the Dusk Rose",'C',4,(0,0,0,0,1,2,1,3),'A','ALT','V',"Cresce a cada morte e devolve o poder em fichas com vínculo vital.",(1,1))
c("Falkenrath Pit Fighter",'C',1,(0,2,0,0,3,0,0,1),'B','MÉD','V SAC',"Vampiro de 1 para o turno 1; depois troca ficha e carta por duas cartas.",(2,1))
c("Florian, Voldaren Scion",'C',3,(0,3,0,0,2,0,1,0),'A','ALT','V CR',"Depois do ataque, olha tantas cartas quanto a vida que a mesa perdeu.",(3,3))
c("Gifted Aetherborn",'C',2,(0,0,0,0,3,0,0,1),'B','MÉD','V',"2/3 com toque mortífero e vínculo; bom, mas genérico.",(2,3))
c("Knight of the Ebon Legion",'C',1,(0,0,0,0,3,1,1,0),'A','ALT','V',"Vampiro de 1 que vira 4/5 com toque mortífero e cresce quando a mesa sangra.",(1,2))
c("Legion Lieutenant",'C',2,(0,0,0,0,3,3,0,0),'S','INS','V L',"Lorde de 2: o reajuste que incide sobre a base inteira desde o turno 2.",(2,2))
c("Markov Baron",'C',3,(0,0,0,0,2,3,0,1),'A','ALT','V L PET',"Lorde com convocar: as fichas pagam o próprio lorde.",(2,2))
c("Mavren Fein, Dusk Apostle",'C',3,(0,0,0,0,2,0,1,0),'B','MÉD','V TK',"Ficha a cada ataque de Vampiro que não é ficha; com Isshin, duas.",(2,2))
c("Mirror Entity",'C',3,(0,0,0,0,2,0,3,0),'A','ALT','V CH EV',"Changeling: dispara a eminência; no fim, X/X para a horda inteira.",(1,1))
c("Nighthawk Scavenger",'C',3,(0,0,0,0,2,0,1,1),'B','MÉD','V',"Voador forte, mas sem relação com a horda.",(3,3))
c("Olivia Voldaren",'C',4,(0,0,2,0,1,1,0,0),'A','ALT','V',"Pinga criaturas e as torna Vampiros: remoção repetível que alimenta lordes.",(3,3))
c("Olivia, Crimson Bride",'C',6,(0,0,0,0,1,0,2,1),'B','MÉD','V',"Seis manas que disputam o turno com o Edgar.",(3,4))
c("Preacher of the Schism",'C',3,(0,2,0,0,2,0,1,0),'A','ALT','V CR TK',"Ataca e compra ou faz ficha; casa com a mesa casual.",(2,4))
c("Roaming Throne",'C',4,(0,1,0,0,0,3,1,1),'A','ALT','CT',"Escolha Vampire: dobra os gatilhos dos Vampiros; com o Edgar em campo, eminência e ataque dobram.",(4,4))
c("Ruthless Lawbringer",'C',3,(0,0,3,0,2,0,0,1),'A','ALT','V SAC',"Vampiro de 3 que troca uma ficha por qualquer permanente.",(3,2))
c("Stromkirk Captain",'C',3,(0,0,0,0,2,3,1,0),'S','INS','V L',"Lorde que dá iniciativa à horda inteira.",(2,2))
c("Vampire Nocturnus",'C',4,(0,0,0,0,1,2,2,0),'B','MÉD','V PET',"+2/+1 e voar quando o topo é preto: perto de metade das vezes.",(3,3))
c("Vampire Socialite",'C',2,(0,0,0,0,3,2,0,0),'B','MÉD','V CT',"Conjurada depois do combate, põe marcador em todos os Vampiros.",(2,2))
c("Vampire of the Dire Moon",'C',1,(0,0,0,0,3,0,0,1),'B','MÉD','V',"Vampiro de 1 para a eminência do turno 1.",(1,1))
c("Vito, Fanatic of Aclazotz",'C',4,(0,0,0,0,1,0,1,2),'C','MÉD','V',"Pede três sacrifícios no turno para render tudo.",(2,2))
c("Vito, Thorn of the Dusk Rose",'C',3,(0,0,0,0,2,0,2,3),'A','ALT','V PET CBK DR',"Peça do combo; com a habilidade de vínculo, a horda inteira drena.",(1,3))
c("Welcoming Vampire",'C',3,(0,3,0,0,2,0,1,0),'S','INS','V CR',"Uma carta por turno, porque toda eminência faz entrar um 1/1.",(2,3))
c("Yahenni, Undying Partisan",'C',3,(0,0,0,1,2,1,0,3),'B','ALT','V PET SAC',"Saída de sacrifício grátis que se protege.",(2,2))
# ---------- lista atual: outros ----------
c("Akroma's Will",'O',4,(0,0,0,3,0,0,3,0),'S','INS','EV PZ',"Dois modos só com o Edgar em campo; com ele, voar e golpe duplo na horda inteira é o letal.")
c("Anguished Unmaking",'O',3,(0,0,3,0,0,0,0,0),'A','ALT','PET',"Exílio instantâneo de qualquer permanente não terreno.")
c("Anointed Procession",'O',4,(0,0,0,0,3,0,0,0),'A','ALT','TK',"Dobra a eminência: cada Vampiro conjurado vira três corpos.")
c("Banner of Kinship",'O',5,(0,0,0,0,0,3,1,0),'A','ALT','L PET',"Com oito Vampiros, +8/+8 permanente; só conta quem está em campo quando entra.")
c("Blood for the Blood God!",'O',11,(0,2,0,0,0,0,2,1),'C','BAX','',"Brilha só depois de uma limpeza; num deck que ataca, o desconto raramente chega.")
c("Bolas's Citadel",'O',6,(1,3,0,0,0,0,0,1),'A','ALT','PET GC CR',"Curva baixa paga em vida; sacrificar dez permanentes é fechamento de mesa.")
c("Chaos Warp",'O',3,(0,0,3,0,0,0,0,0),'B','MÉD','',"Responde qualquer permanente, em vermelho.")
c("Coat of Arms",'O',5,(0,0,0,0,0,3,3,0),'A','ALT','L EV',"Com quinze Vampiros, +14/+14 em cada; é simétrico, então olhe as tribos da mesa.")
c("Cover of Darkness",'O',2,(0,0,0,0,0,0,2,0),'B','MÉD','EV',"Medo para a tribo: só criatura preta ou artefato bloqueia.")
c("Damn",'O',2,(0,0,3,0,0,0,0,0),'A','ALT','WP',"Remoção de 2 e, se precisar, limpeza de 4.")
c("Deadly Dispute",'O',2,(1,2,0,0,0,0,0,2),'A','ALT','SAC',"Uma ficha da eminência vira duas cartas e um Tesouro.")
c("Descendants' Fury",'O',4,(0,0,0,0,1,0,1,1),'C','BAX','',"Põe no campo, então não dispara a eminência, e pede dano e sacrifício.")
c("Faithless Looting",'O',1,(0,1,0,0,0,0,0,0),'D','BAX','',"Perde carta; só conversa com a loucura do Markov Baron.")
c("Idol of Oblivion",'O',2,(0,2,0,0,0,0,0,0),'A','ALT','CR',"A eminência cria ficha todo turno, e o ídolo compra todo turno.")
c("Invasion of New Capenna",'O',2,(0,0,2,0,0,2,1,1),'B','ALT','',"Remove com uma ficha; derrotada, vira equipamento que põe marcadores na tribo a cada ataque.")
c("Kindred Charge",'O',6,(0,0,0,0,2,0,3,0),'A','ALT','EV TK',"Copia a horda inteira com ímpeto: dobra o dano do turno.")
c("Legion's Landing",'O',1,(1,0,0,0,2,0,0,0),'A','ALT','TK',"Ficha no turno 1 e terreno que fabrica Vampiros quando você ataca com três.")
c("Lich-Knights' Conquest",'O',5,(0,1,0,0,0,0,0,2),'B','MÉD','PET',"Fichas viram reanimação; põe, não conjura.")
c("March of the Canonized",'O',2,(0,0,0,0,2,0,0,0),'C','BAX','TK',"X fichas por X+2: caro pelo que dá.")
c("Necropotence",'O',3,(0,3,0,0,0,0,0,0),'A','ALT','GC CR',"Compra paga em vida, num deck que ganha vida com facilidade.")
c("New Blood",'O',4,(0,0,2,0,0,0,0,0),'B','MÉD','',"Rouba e converte uma criatura, como feitiço de 4.")
c("Olivia's Wrath",'O',5,(0,0,3,0,0,0,0,0),'S','INS','US',"Limpeza que poupa a tribo e escala com ela.")
c("Pact of the Serpent",'O',3,(0,3,0,0,0,0,0,0),'A','ALT','',"Compra X cartas, X = Vampiros: com a horda, mão cheia.")
c("Rite of Oblivion",'O',2,(0,0,3,0,0,0,0,1),'A','ALT','SAC',"Uma ficha paga o exílio, e a carta volta do cemitério.")
c("Ruinous Ultimatum",'O',7,(0,0,3,0,0,0,1,0),'A','ALT','PET US',"Limpa só a mesa deles; exige RRWWWBB.")
c("Shared Animosity",'O',3,(0,0,0,0,0,0,3,0),'S','INS','EV',"Com doze atacantes, cada um ganha +11/+0.")
c("Skullclamp",'O',1,(0,3,0,0,0,0,0,1),'S','INS','CR',"Ficha 1/1 equipada morre e compra duas por {1}.")
c("Teferi's Protection",'O',3,(0,0,0,3,0,0,0,0),'A','ALT','GC PZ',"Atravessa a limpeza com o campo inteiro.")
c("Toxic Deluge",'O',3,(0,0,3,0,0,0,0,0),'C','BAX','WP',"Mata a sua horda junto; na mesa casual, a limpeza unilateral rende mais.")
c("Your Temple Is Under Attack",'O',3,(0,1,0,2,0,0,0,0),'B','MÉD','PZ',"Indestrutível de 3 ou compra simétrica.")
# ---------- lista atual: terrenos ----------
c("Arid Mesa",'L',0,(2,0,0,0,0,0,0,0),'B','ALT','PET',"Busca o triome; na forte, também as três shocks.")
c("Blightstep Pathway",'L',0,(1,0,0,0,0,0,0,0),'B','MÉD','',"B ou R, desvirada, uma face só.")
c("Brightclimb Pathway",'L',0,(1,0,0,0,0,0,0,0),'B','MÉD','',"W ou B, desvirada, uma face só.")
c("Command Tower",'L',0,(3,0,0,0,0,0,0,0),'A','INS','PET',"As três cores, desvirada.")
c("Crystal Grotto",'L',0,(1,0,0,0,0,0,0,0),'C','BAX','',"Incolor, ou paga 1 para filtrar.")
c("Dragonskull Summit",'L',0,(2,0,0,0,0,0,0,0),'B','MÉD','',"B ou R; desvirada com Swamp ou Mountain (o triome conta).")
c("Exotic Orchard",'L',0,(2,0,0,0,0,0,0,0),'B','MÉD','',"Na mesa de quatro, quase sempre as três cores.")
c("Fabled Passage",'L',0,(1,0,0,0,0,0,0,0),'B','MÉD','PET',"Básico virado até o quarto terreno.")
c("Fetid Heath",'L',0,(1,0,0,0,0,0,0,0),'B','MÉD','',"Filtro W/B: precisa de mana colorida para render.")
c("Fountainport",'L',0,(1,1,0,0,0,0,0,0),'B','MÉD','',"Incolor; no jogo longo, sacrifica ficha e compra.")
c("Graven Cairns",'L',0,(1,0,0,0,0,0,0,0),'B','MÉD','',"Filtro B/R.")
c("Luxury Suite",'L',0,(2,0,0,0,0,0,0,0),'B','ALT','',"B ou R, desvirada na mesa de quatro.")
c("Mountain",'L',0,(1,0,0,0,0,0,0,0),'B','ALT','',"Básico (alvo dos fetches).")
c("Needleverge Pathway",'L',0,(1,0,0,0,0,0,0,0),'B','MÉD','',"R ou W, desvirada, uma face só.")
c("Nomad Outpost",'L',0,(2,0,0,0,0,0,0,0),'B','MÉD','TAP',"As três cores, sempre virada.")
c("Path of Ancestry",'L',0,(2,0,0,0,0,0,0,0),'B','ALT','TAP',"Qualquer cor, virada; vidência ao conjurar Vampiro.")
c("Plains",'L',0,(1,0,0,0,0,0,0,0),'B','ALT','',"Básico.")
c("Rugged Prairie",'L',0,(1,0,0,0,0,0,0,0),'C','MÉD','',"Filtro R/W: o par que o deck menos usa.")
c("Savai Triome",'L',0,(2,0,0,0,0,0,0,0),'B','ALT','PET TAP',"As três cores, virada; tem os três tipos básicos para os fetches.")
c("Secluded Courtyard",'L',0,(1,0,0,0,0,0,0,0),'B','MÉD','',"Qualquer cor só para criatura do tipo escolhido.")
c("Shattered Landscape",'L',0,(0,0,0,0,0,0,0,0),'C','BAX','',"Incolor, ou um básico virado: lento demais.")
c("Swamp",'L',0,(1,0,0,0,0,0,0,0),'B','ALT','',"Básico.")
c("Temple of Malice",'L',0,(1,0,0,0,0,0,0,0),'C','MÉD','TAP',"B/R virada, vidência 1.")
c("Temple of Silence",'L',0,(1,0,0,0,0,0,0,0),'B','MÉD','TAP',"W/B virada, vidência 1; o par mais importante.")
c("Temple of Triumph",'L',0,(1,0,0,0,0,0,0,0),'C','BAX','TAP',"R/W virada: o par menos usado.")
c("Temple of the False God",'L',0,(0,0,0,0,0,0,0,0),'D','BAX','',"Só funciona com cinco terrenos, num deck de 32.")
c("Unclaimed Territory",'L',0,(1,0,0,0,0,0,0,0),'B','MÉD','',"Qualquer cor só para criatura do tipo escolhido.")
c("Valgavoth's Lair",'L',0,(0,0,0,0,0,0,0,0),'D','BAX','TAP',"Uma cor, sempre virada.")
c("Vault of the Archangel",'L',0,(1,0,0,0,0,0,2,1),'B','ALT','',"Toque mortífero e vínculo para todos; com o Vito, cada atacante drena.")
c("Voldaren Estate",'L',0,(1,1,0,0,0,0,0,0),'B','ALT','',"Qualquer cor para Vampiro; no fim, Sangue barato.")
c("Windbrisk Heights",'L',0,(0,0,0,0,0,0,1,0),'C','MÉD','TAP',"Virada; mágica grátis quando três atacam.")
# ---------- entradas ----------
c("Blood Crypt",'L',0,(2,0,0,0,0,0,0,0),'A','ALT','',"B/R desvirada (2 de vida) e alvo dos fetches.")
c("Godless Shrine",'L',0,(2,0,0,0,0,0,0,0),'A','ALT','',"W/B desvirada, o par mais pedido pela lista.")
c("Sacred Foundry",'L',0,(2,0,0,0,0,0,0,0),'A','ALT','',"R/W desvirada e alvo dos fetches.")
c("Marsh Flats",'L',0,(2,0,0,0,0,0,0,0),'A','ALT','',"Busca Plains ou Swamp: acha as três shocks e o triome.")
c("Bloodstained Mire",'L',0,(2,0,0,0,0,0,0,0),'A','ALT','',"Busca Swamp ou Mountain: acha as três shocks e o triome.")
c("Three Tree City",'L',0,(2,0,0,0,0,0,1,0),'A','ALT','',"Escolha Vampire: com dez Vampiros, {2} vira dez manas de uma cor.")
c("Sol Ring",'O',1,(3,0,0,0,0,0,0,0),'S','INS','',"Duas manas por uma: Edgar no turno 4.")
c("Arcane Signet",'O',2,(2,0,0,0,0,0,0,0),'A','ALT','',"Qualquer das três cores.")
c("Smothering Tithe",'O',4,(3,0,0,0,0,0,0,0),'A','ALT','GC',"Na mesa casual quase ninguém paga: Tesouro toda rodada.")
c("Sanctum Seeker",'C',4,(0,0,0,0,1,0,3,2),'S','INS','V DR',"Cada Vampiro que ataca drena cada oponente em 1; com Isshin, em 2. Bloquear não salva ninguém.",(3,4))
c("Isshin, Two Heavens as One",'C',3,(0,0,0,0,0,2,3,0),'S','INS','',"Dobra todo gatilho de ataque: marcadores do Edgar, dreno do Seeker, Shared Animosity, Mavren, Preacher, Clavileño.",(3,4))
c("Iroas, God of Victory",'O',4,(0,0,0,2,0,0,3,0),'A','ALT','EV PZ',"Menace na horda e nenhum dano nos atacantes: atacar todo turno sai de graça.")
c("Bloodletter of Aclazotz",'C',4,(0,0,0,0,1,0,3,1),'A','ALT','V',"No seu turno, toda perda de vida deles dobra, combate incluído.",(2,4))
c("Stensian Sanguinist",'C',2,(0,0,1,0,3,0,3,1),'A','ALT','V',"Vampiro de 2 que vira um Exsanguinate em cada turno em que a horda conecta.",(2,2))
c("Crippling Fear",'O',4,(0,0,3,0,0,0,0,0),'A','ALT','US',"Escolha Vampire: só as criaturas deles levam −3/−3.")
c("Indulgent Aristocrat",'C',1,(0,0,0,0,3,3,0,3),'S','INS','V SAC CT',"Vampiro de 1 que transforma qualquer ficha em +1/+1 para a tribo inteira.",(1,1))
c("Emeritus of Woe",'C',4,(0,3,0,0,1,0,0,1),'S','INS','V',"Um Demonic Tutor ao entrar e outro a cada turno com duas mortes; não é Game Changer.",(5,4))
c("Scheming Silvertongue",'C',2,(0,2,0,0,3,0,1,1),'A','ALT','V CR',"Vampiro de 2 voador com vínculo; ganhando 2 de vida no turno, conjura Sign in Blood de novo.",(1,3))
c("Demonic Tutor",'O',2,(0,3,0,0,0,0,0,0),'A','ALT','GC',"Busca a peça que falta: Skullclamp, Shared Animosity, Isshin ou o combo.")
c("Vampiric Tutor",'O',1,(0,3,0,0,0,0,0,0),'A','ALT','GC',"Busca instantânea de 1; põe no topo.")
c("Edgar, Ancient Bloodlord",'C',2,(0,0,0,0,3,1,1,3),'B','MÉD','V SAC',"O Edgar de 2026: saída de sacrifício de 2 que ganha vida a cada morte e alimenta Vito e Silvertongue.",(2,3))
c("Clever Concealment",'O',4,(0,0,0,3,0,0,0,0),'A','ALT','PZ',"Tira de fase o seu campo; com convocar, as fichas pagam quase tudo.")
# ---------- trocas da versão forte ----------
# (sai, entra, camada, no_atalho)
PARES=[
 ("Temple of the False God","Blood Crypt",1,True),
 ("Valgavoth's Lair","Godless Shrine",1,True),
 ("Crystal Grotto","Sacred Foundry",1,False),
 ("Temple of Triumph","Marsh Flats",1,False),
 ("Temple of Malice","Bloodstained Mire",1,False),
 ("Shattered Landscape","Three Tree City",1,False),
 ("Faithless Looting","Sol Ring",1,True),
 ("Bloodlord of Vaasgoth","Arcane Signet",1,False),
 ("Descendants' Fury","Smothering Tithe",1,False),
 ("Vito, Fanatic of Aclazotz","Sanctum Seeker",2,True),
 ("March of the Canonized","Isshin, Two Heavens as One",2,True),
 ("Blood for the Blood God!","Iroas, God of Victory",2,False),
 ("Carmen, Cruel Skymarcher","Bloodletter of Aclazotz",2,True),
 ("Gifted Aetherborn","Stensian Sanguinist",2,True),
 ("Toxic Deluge","Crippling Fear",2,True),
 ("Dusk Legion Sergeant","Indulgent Aristocrat",3,True),
 ("Olivia, Crimson Bride","Emeritus of Woe",3,True),
 ("Nighthawk Scavenger","Scheming Silvertongue",3,False),
 ("New Blood","Demonic Tutor",3,False),
 ("Drana and Linvala","Vampiric Tutor",3,False),
 ("Vampire of the Dire Moon","Edgar, Ancient Bloodlord",3,False),
 ("Your Temple Is Under Attack","Clever Concealment",4,False),
]
CAMADAS={1:"Mana no turno certo",2:"A horda fecha o jogo",3:"Motor: compra e busca",4:"Proteção",5:"Base larga: mais terreno e Vampiro barato"}
# ---------- camada 5 (proposta, medida à parte) ----------
c("Bloodtithe Harvester",'C',2,(0,0,2,0,3,0,0,1),'A','ALT','V',"Remoção que também é Vampiro de 2 e dispara a eminência.",(3,2))
c("Voldaren Epicure",'C',1,(0,0,0,0,3,0,1,0),'B','MÉD','V',"Vampiro de 1; o dano de entrada liga Socialite, Knight e Pit Fighter no mesmo turno.",(1,1))
c("Cavern of Souls",'L',0,(2,0,0,0,0,0,0,0),'A','ALT','',"Qualquer cor para Vampiro, sem contramágica.")
c("Vault of Champions",'L',0,(2,0,0,0,0,0,0,0),'A','ALT','',"W/B desvirada na mesa de quatro.")
CAMADA5=[("Chaos Warp","Bloodtithe Harvester",5,False),("Mavren Fein, Dusk Apostle","Voldaren Epicure",5,False),("Idol of Oblivion","Cavern of Souls",5,False),("Cover of Darkness","Vault of Champions",5,False)]

PARES_22=list(PARES)
PARES=PARES+CAMADA5
# ---------- auditoria (15/10/2026): candidatas de mana, texto no cache v2.4 ----------
c("Talisman of Hierarchy",'O',2,(2,0,0,0,0,0,0,0),'B','MÉD','',"Pedra de 2 que faz W ou B (1 de dano) ou incolor: Edgar um turno antes.")
c("Talisman of Indulgence",'O',2,(2,0,0,0,0,0,0,0),'B','MÉD','',"Pedra de 2 que faz B ou R (1 de dano) ou incolor: Edgar um turno antes.")
c("Talisman of Conviction",'O',2,(2,0,0,0,0,0,0,0),'B','MÉD','',"Pedra de 2 que faz R ou W (1 de dano) ou incolor.")
c("Fellwar Stone",'O',2,(2,0,0,0,0,0,0,0),'B','MÉD','',"Pedra de 2 que faz qualquer cor que um terreno de oponente produziria.")
c("Black Market Connections",'O',3,(2,2,0,0,1,0,0,0),'A','ALT','',"Tesouro, carta ou um 3/2 changeling por turno, pagos em vida.")
# ---------- auditoria (15/10/2026): trocas e tiers revistos ----------
PARES=[p for p in PARES if p[0]!="Vampire of the Dire Moon"]
CAMADAS[6]="Mana medida na auditoria"
CAMADA6=[("Coat of Arms","Talisman of Hierarchy",6,False),("Kindred Charge","Talisman of Indulgence",6,False)]
PARES=PARES+CAMADA6
# Regra de tier: S só para carta sem substituta no plano. Lordes (8) e limpezas unilaterais (3) são redundantes.
for _n in ["Bloodline Keeper","Captivating Vampire","Legion Lieutenant","Stromkirk Captain","Akroma's Will","Olivia's Wrath","Indulgent Aristocrat"]:
    D[_n]['tier']='A'; D[_n]['rel']='ALT'
D["Akroma's Will"]['porque']="O modo de voar e golpe duplo, que é o letal, não precisa do Edgar. Os dois modos juntos só com ele em campo (regra 903.3d)."
D["Olivia's Wrath"]['porque']="Limpeza que poupa a tribo e escala com ela. Mata o Isshin (Humano) a partir de quatro Vampiros."
D["Isshin, Two Heavens as One"]['porque']="Dobra todo gatilho de ataque: marcadores do Edgar, dreno do Seeker, Shared Animosity, Preacher, Clavileño. É Humano: morre para o seu Olivia's Wrath."
D["Sanctum Seeker"]['porque']="Cada Vampiro que ataca tira 1 de cada oponente antes dos bloqueios; com Isshin, 2; com Isshin e Bloodletter, 4."
D["Bloodletter of Aclazotz"]['porque']="No seu turno, toda perda de vida dos oponentes dobra, combate e drenos incluídos. Com Seeker e Isshin, 4 de cada oponente por atacante."
D["Toxic Deluge"]['porque']="Mata a sua horda junto. No Clavileño é S porque lá a morte é o motor; aqui a horda é o capital."
D["Coat of Arms"]['porque']="Simétrico: numa mesa de tribais dá o mesmo bônus ao vizinho. Na auditoria, a pedra no lugar dela rendeu mais no motor."
D["Kindred Charge"]['porque']="Seis manas por um turno de dano. Na auditoria, a pedra no lugar dela rendeu mais no motor."
D["Vampire of the Dire Moon"]['porque']="Vampiro de 1 para a eminência do turno 1. Fica: a base larga cedo é a tese do deck."
D["Vito, Thorn of the Dusk Rose"]['porque']="Peça do combo: qualquer perda de vida de um oponente, com o Conqueror em campo, vira laço infinito."

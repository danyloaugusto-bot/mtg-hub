import sys,json,time
import sim_audit as S
from motor import atual,montar,checar
from dados import PARES
A=atual(); F=montar(A,PARES); AT=montar(A,[p for p in PARES if p[3]])
def troca(L,pares):
    L=list(L)
    for sai,entra in pares:
        assert L.count(sai)==1,(sai); L.remove(sai); L.append(entra)
    return L
PRI_ORIG=list(S.TUTOR_PRI)
PRI_DRENO=["Sanctum Seeker","Bloodletter of Aclazotz","Isshin, Two Heavens as One","Skullclamp","Shared Animosity","Anointed Procession","Legion Lieutenant","Stromkirk Captain","Captivating Vampire","Welcoming Vampire"]
V={}
V['hoje']=(A,PRI_ORIG)
V['forte']=(F,PRI_ORIG)
V['atalho']=(AT,PRI_ORIG)
V['forte_busca_dreno']=(F,PRI_DRENO)
V['forte_dire_moon']=(troca(F,[("Edgar, Ancient Bloodlord","Vampire of the Dire Moon")]),PRI_DRENO)
V['forte_2pedras_terra']=(troca(F,[("Windbrisk Heights","Talisman of Hierarchy"),("Rugged Prairie","Talisman of Indulgence")]),PRI_DRENO)
V['forte_2pedras_magia']=(troca(F,[("Coat of Arms","Talisman of Hierarchy"),("Edgar, Ancient Bloodlord","Talisman of Indulgence")]),PRI_DRENO)
V['forte_bmc_terra']=(troca(F,[("Windbrisk Heights","Black Market Connections")]),PRI_DRENO)
V['forte_bmc_e_talisma']=(troca(F,[("Windbrisk Heights","Black Market Connections"),("Rugged Prairie","Talisman of Hierarchy")]),PRI_DRENO)
V['atalho_busca_dreno']=(AT,PRI_DRENO)
if __name__=="__main__":
  sel=sys.argv[2:] or list(V)
  N=int(sys.argv[1])
  out={}
  for k in sel:
    L,pri=V[k]; checar(L,k); S.CFG['tutor']=pri
    t=time.time(); r=S.rodar(L,N); out[k]=r
    print(k,{a:round(b,3) for a,b in r.items()},f'{time.time()-t:.0f}s',flush=True)
  json.dump(out,open(f'/home/claude/edgar/audit_{"_".join(sel) if len(sel)<3 else "todos"}_{N}.json','w'),indent=1)

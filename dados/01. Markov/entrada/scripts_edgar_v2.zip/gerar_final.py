import json,sys
sys.path.insert(0,'/home/claude/edgar/scripts')
from motor import *
import dados
B='/home/claude/edgar/'
M=json.load(open(B+'sim_resultado.json')); S=json.load(open(B+'stats_versoes.json'))
V1=json.load(open(B+'audit_todos_20000.json')); V2=json.load(open(B+'audit2.json'))
def pc(x): return f"{x*100:.0f}%"
def pc1(x): return f"{x*100:.1f}%".replace('.',',')
def d1(x): return f"{x:.1f}".replace('.',',')
def pt(a,b): return f"{(b-a)*100:+.1f}".replace('.',',')
h,fo,f,a=M['hoje'],M['forte_outra_conversa'],M['forte'],M['atalho']
gan=lambda k:(a[k]-h[k])/(f[k]-h[k])
NT=len(dados.PARES)
L=[]; w=L.append
# ---------------- segunda metade da análise ----------------
w("# Parte 2: forte, atalho e motor")
w("")
w("## Nota de chegada")
w("")
w("| | Hoje | Forte | Atalho |\n|---|---|---|---|")
w("| Nota | 6,5 | 8,5 (projetada) | 7,5 (projetada) |")
w(f"| Placar | {S['atual']['placar']} | {S['forte']['placar']} | {S['atalho']['placar']} |")
w("| Game Changers / Bracket | 3 / B3 | 6 / B4 | 3 / B3 |")
w("")
w(f"**O gargalo medido é a mana, e a forte final ataca isso.** A lista de hoje põe o Edgar em campo até o turno 6 em {pc(h['p_edgar_t6'])} das partidas. A forte da outra conversa chegava a {pc(fo['p_edgar_t6'])}; a forte final, com duas pedras no lugar de Coat of Arms e Kindred Charge, chega a {pc(f['p_edgar_t6'])}. A mesa morta até o turno 8 vai de {pc(h['p_mesa_t8'])} hoje para {pc(f['p_mesa_t8'])}.")
w("")
w(f"**O placar caiu de 474 para {S['forte']['placar']}, e isso não é perda.** O placar bate no teto de aceleração em todas as versões, então não enxerga mana nem turno. Duas pedras pontuam menos nos eixos que dois finalizadores, mas o motor medido melhora. A decisão foi tomada pela simulação.")
w("")
w("## 4b. O motor, medido")
w("")
w("Goldfish guloso, na jogada, sem mulligan e sem oponente, 20 mil partidas por versão. Joga terreno, pedras, o Edgar a partir do turno 4 se houver 6 manas com as três cores, e então os Vampiros do mais barato ao mais caro. Ataca com tudo. O relógio da mesa é o turno em que o dano somado passa de 120 (três oponentes com 40) ou em que o combo do Vito fica montado.")
w("")
w("| Medida | Hoje | Forte | Atalho |\n|---|---|---|---|")
rows=[("Vampiros em campo no fim do turno 4 (média)",'vampiros_t4',d1),("Edgar em campo até o turno 6",'p_edgar_t6',pc),("Turno mediano do Edgar",'edgar_mediana',lambda x:f"{x:.0f}"),("Mesa morta até o turno 7",'p_mesa_t7',pc),("Mesa morta até o turno 8",'p_mesa_t8',pc),("Turno mediano do relógio",'relogio_mediana',lambda x:f"{x:.0f}"),("Cartas vistas até o turno 6",'cartas_vistas_t6',d1),("Seeker e Bloodletter atacando com 8 Vampiros até o turno 8",'p_linha_t8',pc1),("O mesmo com Isshin e 5 Vampiros até o turno 8",'p_linha_isshin_t8',pc1),("Combo do Vito montado até o turno 8",'p_combo_t8',pc1)]
for n,k,fm in rows: w(f"| {n} | {fm(h[k])} | {fm(f[k])} | {fm(a[k])} |")
w("")
w(f"**A razão do atalho.** Com 10 das {NT} trocas, o atalho entrega {gan('p_mesa_t8')*100:.0f}% do ganho da forte na mesa morta até o turno 8, mas só {gan('p_edgar_t6')*100:.0f}% do ganho no Edgar até o turno 6. A diferença está na mana: o atalho leva Sol Ring e duas shocks; a forte leva também Signet, dois Talismans, Tithe, Three Tree City e dois terrenos a mais. Placar e motor divergem de novo, como nos vermelhos.")
w("")
w("**Como conferi o simulador.** Rodei de novo os scripts da outra conversa e reproduzi os números dela (Edgar até o turno 6 na forte: 32%; mesa morta até o turno 8: 44%). Depois, uma partida à mão da forte final, semente 7: Captivating Vampire no 3; Deadly Dispute e Blood Artist no 4; o Edgar no 5, atacando com quatro criaturas para 14 (cada Vampiro com o marcador do ataque e o +1 do lorde); Shared Animosity no 7, com oito atacantes. A ordem faz sentido.")
w("")
w("**Hipóteses que pesam (o que o simulador não vê):**")
w("")
for x in ["Não há bloqueadores. Iroas e o menace não aparecem nos números; o Sanctum Seeker aparece, e por isso pesa tanto.",
"Remoção, proteção, limpeza e reanimação ficam na mão, porque no goldfish não há alvo. Por isso a simulação não sabe o valor do Coat of Arms numa mesa travada.",
"A vida não é contada: Necropotence, Citadel, Pact of the Serpent, shocks e fetches saem de graça. Isso favorece um pouco a forte.",
"Convocar (Markov Baron, Clever Concealment) não foi modelado, o que subestima um pouco hoje e a forte.",
"Smothering Tithe rende 2 Tesouros por rodada. Necropotence rende 3 cartas por turno. O Citadel vale 1 carta por turno.",
"As buscas vão primeiro para Sanctum Seeker, Bloodletter e Isshin, e só depois para Skullclamp e Shared Animosity.",
"Poder e resistência das criaturas vêm de memória, porque o cache não traz esses números. Os que decidem foram conferidos na fonte: Sanctum Seeker 3/4, Isshin 3/4, Bloodletter 2/4.",
"Filtros (Fetid Heath, Graven Cairns, Rugged Prairie) contam como dupla desvirada, o que favorece um pouco a lista de hoje."]: w("- "+x)
w("")
w("## 5. Linhas de jogo")
w("")
w("**Motores.**")
w("")
for x in ["Eminência mais Anointed Procession: cada Vampiro conjurado vira três corpos.",
"Skullclamp sem lorde em campo: {1} compra 2 com uma ficha. Com lorde, as fichas não morrem com +1/−1, e o Clamp passa a precisar de saída de sacrifício. Yahenni é a grátis; o Indulgent Aristocrat cobra {2}.",
"Welcoming Vampire compra uma carta por turno, porque a eminência faz entrar ficha todo turno.",
"Emeritus of Woe: um Demonic Tutor ao entrar e de novo no fim de qualquer turno em que duas criaturas morreram. A cópia é um feitiço, não um Vampiro: não dispara a eminência."]: w("- "+x)
w("")
w("**Fechamentos, do mais barato ao mais caro.**")
w("")
for x in ["Sanctum Seeker com a horda atacando: cada Vampiro que ataca tira 1 de vida de cada oponente, antes dos bloqueios. Isshin ou Roaming Throne dobram; os dois juntos quadruplicam. O Bloodletter dobra toda perda de vida no seu turno. Seeker, Isshin e Bloodletter juntos: 4 de cada oponente por atacante; dez atacantes tiram 40 de cada um. É o teto do deck, não a rotina: as três peças juntas são raras até o turno 8. Mas apontar as buscas para o Seeker e o Bloodletter rendeu cerca de 3 pontos na mesa morta até o turno 8.",
"Shared Animosity com doze atacantes: +11/+0 em cada um, o dobro com Isshin.",
"Stensian Sanguinist: sempre que você ataca, uma criatura ganha toque mortífero; se ela causar dano de combate a um jogador, o Sanguinist fica preparado, e na segunda fase principal você conjura uma cópia de Exsanguinate com a mana que sobrar. Com Three Tree City e dez Vampiros, X passa de 10: 30 de vida na mesa, 60 com o Bloodletter.",
"Akroma's Will: o modo de voar e golpe duplo, que dobra o dano do turno, funciona sem o Edgar. Com o Edgar em campo você ganha também o segundo modo (vínculo, indestrutível e proteção), o que protege o ataque de uma resposta. Não segure a carta esperando o Edgar.",
"Plano B: Vito + Bloodthirsty Conqueror. Com os dois em campo, qualquer perda de vida de um oponente começa o laço. Busque quando o combate travar."]: _n=globals().get('_n',0)+1; globals()['_n']=_n; w(f"{_n}. {x}")
w("")
w("**Como fechar a mesa, não um jogador.** O Sanctum Seeker e o Exsanguinate atingem cada oponente, e o combate não. Ataque dividido só vale com Seeker ou Bloodletter em campo. Sem eles, concentre no jogador com mais vida, que é também o que liga o Preacher.")
w("")
w("**O momento da jogada.**")
w("")
for x in ["O Edgar entra no turno em que paga 6 com as três cores e ataca na hora (tem ímpeto), de preferência com quatro Vampiros para coroar. Antes disso, cada mana vai para Vampiro barato, porque a eminência já trabalha da zona de comando.",
"Olivia's Wrath com o Isshin em campo mata o Isshin, que é Humano. Prefira o Crippling Fear (ele fica em 0/1) ou desça o Isshin depois da limpeza.",
"Ordem das buscas: Sanctum Seeker, depois Bloodletter, depois Isshin. Skullclamp quando o motor de cartas parar. O combo do Vito quando o combate travar."]: w("- "+x)
w("")
w("## 6b. O atalho")
w("")
w("As 10 trocas marcadas, sem nenhum Game Changer novo:")
w("")
w("- **Mana:** Blood Crypt, Godless Shrine e Sol Ring.")
w("- **Conversão:** Sanctum Seeker, Isshin, Bloodletter, Stensian e Crippling Fear.")
w("- **Motor:** Indulgent Aristocrat e Emeritus.")
w("")
at,ats=V1['atalho_busca_dreno'],V2['AT_signet_stensian']
w(f"A outra conversa sugeria o Arcane Signet no lugar do Stensian. Medi: {pt(at['p_mesa_t8'],ats['p_mesa_t8'])} pontos na mesa morta até o turno 8 e {pt(at['p_edgar_t6'],ats['p_edgar_t6'])} no Edgar até o turno 6. É pouco para tirar a peça que só este deck tem, então o atalho fica como está.")
w("")
w("## 7. Painel")
w("")
w("**Nomes:** Linhagem Markov, Coroação de Sangue e A Corte do Patriarca. Escolho **Linhagem Markov**: a eminência é literalmente a linhagem, e foi com este deck que tudo começou.")
w("")
w("**Clima:** galeria de retratos de família em Innistrad, à luz de lareira. Verniz velho, veludo e prata de castiçal.")
w("")
w("| Cor | Hex | Uso |\n|---|---|---|")
for c in [("Verniz-âmbar","#8C5A2B","Molduras e títulos"),("Veludo-ameixa","#4A1F3D","Fundo das seções"),("Prata-de-castiçal","#C9C6BF","Texto secundário e linhas"),("Carvão-de-lareira","#1B1A1F","Fundo principal"),("Sinete-carmim","#9E1B32","Destaques, Tier S e Game Changers")]: w(f"| {c[0]} | {c[1]} | {c[2]} |")
w("")
w("**Moldura:** retrato oval com filete dourado para o Edgar na capa. **Motivo:** uma árvore genealógica que ganha um ramo para cada Vampiro do deck, com o Edgar no tronco e o Edgar noivo no primeiro galho.")
w("")
w("## 8. Dúvidas")
w("")
for x in ["**Fontes.** Texto das cartas no EDHREC e no Archidekt (cache v2.4); regras no Grimoria e, para a Akroma's Will, a regra 903.3d; combos no Commander Spellbook (314-6191, 110-6191, 690-6191, 314-3966); percentuais nos 51.835 decks do EDHREC, com a coleta marcada como parcial; precon de 2017 completo.",
"**Leitura minha, não regra confirmada:** o Roaming Throne não dobra a eminência com o Edgar na zona de comando, pelo texto \"another creature you control\".",
"**Pets que travam espaço.** Cemetery Gatekeeper, Vampire Nocturnus e Lich-Knights' Conquest rendem pouco aqui, e digo isso uma vez. Os três ficam. Se um dia você liberar um deles, a vaga vai para um Vampiro de 1 ou 2 manas.",
"**Avaliações discutíveis.** Sanctum Seeker e Indulgent Aristocrat são previsíveis (68% e 73% no EDHREC); entraram porque não têm substituta à altura. O Smothering Tithe depende da mesa não pagar. O corte do Coat of Arms vem de um goldfish, que não vê mesa travada: se a sua mesa não tiver outras tribais, ele volta no lugar do Talisman of Indulgence.",
"**A nota.** Os 8,5 e 7,5 são projeção sem partida. O teste das dez mãos decide."]: w("- "+x)
w("")
w("**Teste das dez mãos (metas para a forte):**")
w("")
for x in ["Pelo menos 3 Vampiros em campo no turno 4 em seis das dez mãos.","Edgar em campo até o turno 6 em quatro das dez.","Mesa morta, ou combo montado, até o turno 8 em cinco das dez.","Nenhuma mão travada em dois terrenos no turno 4."]: w("- "+x)
parte2='\n'.join(L)+'\n'
p1=open(B+'analise-claude-edgar_fatia1.md').read().replace('## 8. Dúvidas (parcial)','## 8a. Dúvidas do diagnóstico')
open(B+'final/analise-claude-edgar.md','w').write(p1.rstrip()+'\n\n'+parte2)
json.dump({'h':h,'fo':fo,'f':f,'a':a},open(B+'final/_numeros.json','w'),indent=1)
print('analise ok')

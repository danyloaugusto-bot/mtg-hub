import sys,json; sys.path.insert(0,'/home/claude/edgar/scripts')
from motor import *
M=json.load(open(BASE+'sim_resultado.json')); S=json.load(open(BASE+'stats_versoes.json')); C=json.load(open(BASE+'comparacao/resumo.json'))['res']
pc=lambda x:f"{x*100:.0f}%"
GCS={'Smothering Tithe','Demonic Tutor','Vampiric Tutor'}
tro=[]
for cam in sorted(CAMADAS):
    tro.append(f"- **{CAMADAS[cam]}:**")
    for sai,entra,c_,at in PARES:
        if c_==cam: tro.append(f"  - {sai} → {entra}{'*' if at else ''}{' (Game Changer)' if entra in GCS else ''}")
h=f"""# Handover: Edgar Markov (Linhagem Markov)

Versão 1, de 15/10/2026. Anexo de detalhe do Handover Mestre v2.3.

**Arquivos:**

- `analise-claude-edgar.md` (as duas fatias juntas)
- `lista_forte_edgar.txt`
- `lista_atalho_edgar.txt`
- `cache_cartas_v2.4.json`
- `scripts_edgar.zip`
- `dados_edgar_edhrec_precon.md`

## Estado

Análise completa, em reconstrução forte. O teste das dez mãos ainda não foi feito.

| | Hoje | Forte ({len(PARES)} trocas) | Atalho (10) |
|---|---|---|---|
| Nota (projetada) | 6,5 | 8,5 | 7,5 |
| Placar | {S['atual']['placar']} | {S['forte']['placar']} | {S['atalho']['placar']} |
| Game Changers / Bracket | 3 / B3 | 6 / B4 | 3 / B3 |
| Vampiros em campo no turno 4 | {M['hoje']['vampiros_t4']:.1f} | {M['forte']['vampiros_t4']:.1f} | {M['atalho']['vampiros_t4']:.1f} |
| Edgar em campo até o turno 6 | {pc(M['hoje']['p_edgar_t6'])} | {pc(M['forte']['p_edgar_t6'])} | {pc(M['atalho']['p_edgar_t6'])} |
| Mesa morta até o turno 8 (goldfish) | {pc(M['hoje']['p_mesa_t8'])} | {pc(M['forte']['p_mesa_t8'])} | {pc(M['atalho']['p_mesa_t8'])} |

Nome de painel sugerido: **Linhagem Markov**. Grupo provável: 01. Top.

## O que ele disse

- Foi o deck onde tudo começou; terá sempre um cantinho especial, e por isso ficou por último.
- A força é a eminência. Ele quer estratégia e agrupamentos definitivos, os melhores Vampiros das três cores, e cartas muito sinérgicas.
- "Quero 10", com o melhor esforço. Não se importa com Game Changers nem com bracket na versão forte.
- Plano A: horda no combate. Mesa casual, de jogos longos.
- Sobre os Vampiros: "os melhores, mas não mais do mesmo; nada previsível; tem que ter um porquê".
- Mandou três listas de comparação: Beijo do Vampiro (de um amigo), JoeyDH (Archidekt) e WinterDragon (Moxfield).
- Tem outros 3 ou 4 decks de Vampiros e vai montar mais um ou dois.

## A conta

**Conjurar, coroar, investir.** Cada Vampiro conjurado vale dois corpos. Cada lorde e cada ataque do Edgar somam +1 em todos.

Poder ≈ 2N × (1 + L + k), com N Vampiros conjurados, L lordes e k ataques do Edgar.

Em finanças: a eminência é bonificação em ações, e o lorde é o reajuste que incide sobre a base inteira. A eminência rende por mágica, não por mana. Por isso Vampiro barato e terreno valem mais aqui do que em outros decks.

## Eixos (criados por mim; ele pediu definitivos)

Mana, Compra e busca, Remoção, Proteção, Eminência, Coroação, Investida e Banquete. Os oito passam no crivo.

## O que não pode se perder

- A eminência funciona da zona de comando e só com mágica **conjurada**. Changeling e loucura disparam; "pôr no campo" e cópia preparada não.
- O Edgar precisa estar na zona de comando ou em campo ao conjurar **e** ao resolver.
- Isshin dobra o ataque do Edgar (regra oficial). Roaming Throne só dobra a eminência com o Edgar em campo (leitura minha).
- A Akroma's Will escolhe os dois modos só com o Edgar em campo. É leitura minha pela regra 108.4: carta na zona de comando não tem controlador.
- Skullclamp não mata ficha com lorde em campo; com lorde, precisa de saída de sacrifício (Yahenni é a grátis).
- Cemetery Gatekeeper: nunca exile carta de criatura, que ele queima você também.
- Combo de reserva: Vito, Thorn of the Dusk Rose + Bloodthirsty Conqueror (Spellbook 314-6191).

## Achados

1. **Mana.** 32 terrenos, nenhuma aceleração fora dos terrenos e 8 que entram virados. Em média, 2,8 terrenos e um Vampiro conjurado até o turno 4, e o Edgar em campo até o turno 6 em só {pc(M['hoje']['p_edgar_t6'])} das partidas.
2. **A horda gera e não converte.** Só três cartas atravessam bloqueio, e não há dreno por atacante.
3. **Toxic Deluge mata a própria horda.**
4. **2026 trouxe Vampiros preparados.** Emeritus of Woe (Demonic Tutor repetível, sem ser Game Changer), Stensian Sanguinist (Exsanguinate repetível), Scheming Silvertongue (Sign in Blood) e o Edgar, Ancient Bloodlord, de Reality Fracture.
5. **A lista dele é a menos previsível do grupo:** 36 cartas, fora os básicos, não aparecem em nenhum dos três decks de comparação.

## Onde discordei

- A forte fica um pouco mais previsível na média dos Vampiros ({C['Danylo hoje']['vampmed']:.0f}% para {C['Danylo forte']['vampmed']:.0f}% de inclusão no EDHREC). Saem Vampiros raros que rendem pouco e entram Sanctum Seeker e Indulgent Aristocrat, que não têm substituta à altura. A assinatura do deck passa a ser Isshin, Iroas, Stensian, Emeritus, Crippling Fear e Three Tree City.
- Tier alto não é meta em si: S é o que define o deck. A forte tem {S['forte']['tiers']['S']} cartas S e nenhuma D.

## Trocas

**Forte: {len(PARES)} trocas em {len(CAMADAS)} camadas.** O atalho são as 10 marcadas com asterisco.

"""+'\n'.join(tro)+f"""

## Aberto (com a opção que recomendo)

1. **Forte ou atalho?** Recomendo a forte, porque ele liberou o bracket. O atalho fica como a versão B3 para mesas que pedirem.
2. **O Edgar de 2026 fica?** Recomendo sim. É um B, mas dá ao deck os três Edgars (o patriarca, o noivo e o ancião) e alimenta o Vito e o Silvertongue.
3. **Pets que rendem pouco** (Cemetery Gatekeeper, Vampire Nocturnus, Lich-Knights' Conquest): ficam. Se um dia ele liberar um, a vaga vai para um Vampiro de 1 ou 2 manas.
4. **Nome de painel:** Linhagem Markov, Coroação de Sangue ou A Corte do Patriarca.
5. **Teste das dez mãos da forte**, com as metas da seção 8 da análise.

## Painel

**Clima:** galeria de retratos de família em Innistrad.

**Paleta:**

- Verniz-âmbar #8C5A2B
- Veludo-ameixa #4A1F3D
- Prata-de-castiçal #C9C6BF
- Carvão-de-lareira #1B1A1F
- Sinete-carmim #9E1B32

**Moldura:** retrato oval com filete dourado. **Motivo:** árvore genealógica que ganha um ramo para cada Vampiro.

## Para o Mestre (v2.4)

- **Passo 2:**
  - Edgar: a eminência é gatilho; o Edgar precisa estar na zona de comando ou em campo ao conjurar e ao resolver.
  - "Control a commander" não vale com o comandante na zona de comando (108.4, leitura).
- **Regras novas:**
  - Mecânica "prepare" (2026): a cópia da mágica fica no exílio e é conjurada; não é a criatura.
  - Skullclamp e lordes: ficha com lorde não morre com +1/−1.
- **Fonte nova:** edhrec.com/commanders/<slug> em HTML traz as listas que o JSON corta (o JSON para em uns 72 mil caracteres).
- **Erro evitado:** o simulador tirava fontes de mana erradas depois de pagar, e conjurava remoção sem alvo. Corrigi os dois antes de reportar.
"""
open(BASE+'Handover_Edgar_Analise_de_Deck.md','w').write(h.replace('.1f}','.1f}'))
a=open(BASE+'analise-claude-edgar_fatia1.md').read(); b=open(BASE+'analise-claude-edgar_fatia2.md').read()
open(BASE+'analise-claude-edgar.md','w').write(a.replace('# Análise: Linhagem Markov (Edgar Markov). Fatia 1 de 2: diagnóstico','# Análise: Linhagem Markov (Edgar Markov)\n\n(Fatias 1 e 2 juntas. A forte final tem a camada 5, medida na fatia 2.)\n\n# Fatia 1: diagnóstico',1)+'\n\n'+b.replace('# Análise: Linhagem Markov (Edgar Markov). Fatia 2 de 2: forte, atalho e motor','# Fatia 2: forte, atalho e motor',1))
print('ok')

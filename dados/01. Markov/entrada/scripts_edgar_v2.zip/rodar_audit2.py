import sys,json
import sim_audit as S
from motor import atual,montar,checar,stats
from dados import PARES
from rodar_audit import troca,PRI_DRENO,F,AT
base=troca(F,[("Edgar, Ancient Bloodlord","Vampire of the Dire Moon")])
V={
 'X1_coat_talisma':troca(base,[("Coat of Arms","Talisman of Hierarchy")]),
 'X2_coat_kindred':troca(base,[("Coat of Arms","Talisman of Hierarchy"),("Kindred Charge","Talisman of Indulgence")]),
 'X3_coat_pact':troca(base,[("Coat of Arms","Talisman of Hierarchy"),("Pact of the Serpent","Talisman of Indulgence")]),
 'X4_coat_banner?':None,
 'AT_signet_stensian':troca(AT,[("Stensian Sanguinist","Arcane Signet")]),
}
del V['X4_coat_banner?']
out={}
for k,L in V.items():
    checar(L,k); S.CFG['tutor']=PRI_DRENO; r=S.rodar(L,20000); out[k]=r
    print(k,{a:round(b,3) for a,b in r.items()},'placar',stats(L)['placar'],flush=True)
json.dump(out,open('/home/claude/edgar/audit2.json','w'),indent=1)

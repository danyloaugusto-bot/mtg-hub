import sys,json; sys.path.insert(0,'/home/claude/edgar/scripts')
from motor import *
A=atual(); checar(A,'atual')
F=montar(A,PARES); checar(F,'forte')
AT=montar(A,[p for p in PARES if p[3]]); checar(AT,'atalho')
print('pares forte',len(PARES),'atalho',sum(1 for p in PARES if p[3]))
R={}
for nome,L in [('atual',A),('forte',F),('atalho',AT)]:
    R[nome]=stats(L)
keys=['terrenos','nao_terrenos','cmc','vampiros','vamp_mv12','vamp_mv1','lordes','tap','ramp_nao_terreno','n_MAN','n_CMP','n_REM','massa','unilateral','n_PRO','n_EMI','n_COR','n_INV','n_BAN','soma_notas','pts_cmc','pts_acel','placar','prev_media','prev_50','prev_fora']
for k in keys:
    print(f"{k:18}",' | '.join(f"{R[n][k]:.2f}" if isinstance(R[n][k],float) else str(R[n][k]) for n in R))
for n in R: print(n,'GC',len(R[n]['gc']),R[n]['gc'],'tiers',R[n]['tiers'])
json.dump({n:{k:(v if not isinstance(v,set) else sorted(v)) for k,v in R[n].items()} for n in R},open('/home/claude/edgar/stats_versoes.json','w'),ensure_ascii=False,indent=1)
open('/home/claude/edgar/lista_forte_edgar.txt','w').write('\n'.join(['1 Edgar Markov']+[f"{F.count(x)} {x}" for x in sorted(set(F)) if x!='Edgar Markov']))
open('/home/claude/edgar/lista_atalho_edgar.txt','w').write('\n'.join(['1 Edgar Markov']+[f"{AT.count(x)} {x}" for x in sorted(set(AT)) if x!='Edgar Markov']))

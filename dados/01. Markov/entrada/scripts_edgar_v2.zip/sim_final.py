import json, importlib
import sim_audit as S
from motor import atual,montar,checar
import dados
A=atual(); F=montar(A,dados.PARES); AT=montar(A,[p for p in dados.PARES if p[3]])
F_orig=montar(A,dados.PARES_22+dados.CAMADA5)
PRI_DRENO=["Sanctum Seeker","Bloodletter of Aclazotz","Isshin, Two Heavens as One","Skullclamp","Shared Animosity","Anointed Procession","Legion Lieutenant","Stromkirk Captain","Captivating Vampire","Welcoming Vampire"]
out={}
for nome,L,pri in [('hoje',A,PRI_DRENO),('forte_outra_conversa',F_orig,S.TUTOR_PRI),('forte',F,PRI_DRENO),('atalho',AT,PRI_DRENO)]:
    checar(L,nome); S.CFG['tutor']=pri; out[nome]=S.rodar(L,20000)
    print(nome,{k:round(v,3) for k,v in out[nome].items()},flush=True)
json.dump(out,open('/home/claude/edgar/sim_resultado.json','w'),indent=1)
# partida à mão: forte, semente 7
S.CFG['tutor']=PRI_DRENO
g=S.Jogo(F,7,log=True); g.preparado_emeritus=False; g.xm=0
print('MAO INICIAL:',g.hand)
for t in range(1,8):
    g.turno(t)
print('\n'.join(g.L))

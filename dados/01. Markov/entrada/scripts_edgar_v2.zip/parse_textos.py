import re,json,unicodedata,glob
def norm(n): return unicodedata.normalize('NFKD',n).encode('ascii','ignore').decode().strip().lower()
T={}
for f in sorted(glob.glob('textos/textos_*.md')):
    src=f.split('_')[-1][:-3]
    txt=open(f).read()
    for m in re.finditer(r'^=== (.+?) ===\n(.*?)^=== fim ===',txt,re.S|re.M):
        nome=m.group(1).strip(); body=m.group(2)
        d={'fonte_arq':src}
        for k in ['pedido','fonte','custo','mv','tipo','identidade','game_changer','banned']:
            mm=re.search(r'^'+k+r': (.*)$',body,re.M)
            d[k]=mm.group(1).strip() if mm else None
        mm=re.search(r'^oracle:\n(.*)',body,re.S|re.M)
        d['oracle']=mm.group(1).strip() if mm else None
        T[d['pedido'] or nome]=d
print(len(T))
json.dump(T,open('textos.json','w'),ensure_ascii=False,indent=1)
# cobertura da lista
ed=json.load(open('lista_atual.json'))['cartas']
cache=json.load(open('cache_v23.json'))['cartas']
falta=[c['nome'] for c in ed if c['nome'] not in T and c['nome'] not in cache and c['nome'] not in ('Plains','Swamp','Mountain','Edgar Markov')]
print('sem texto na lista:',falta)
gc=[k for k,v in T.items() if v['game_changer']=='true']
print('GC:',gc)

import re,json,unicodedata
def norm(n): return unicodedata.normalize('NFKD',n).encode('ascii','ignore').decode().strip().lower()
L=open('textos/dados_edgar.md').read().split('\n')
# EDHREC section: lines 15..716 ; edh.wiki 717..1064 ; precon 1065..1190
def grab(a,b,tag):
    out={}
    sec=None
    for i in range(a,b):
        l=L[i]
        m=re.match(r'^#{3,5} (.+)$',l)
        if m: sec=m.group(1); continue
        m=re.match(r'^([^|`#\-][^|]*?) \| ([\d.,]+) ?%?(?: \| ([+\-−]?[\d.,]+|não conferido) ?%?)?\s*$',l)
        if m and sec and 'Valores brutos' not in sec:
            nome=m.group(1).strip()
            if nome in ('nome',): continue
            inc=float(m.group(2).replace(',','.'))
            syn=m.group(3)
            syn=float(syn.replace(',','.').replace('−','-')) if syn and syn!='não conferido' else None
            k=norm(nome)
            if k not in out or out[k]['inc']<inc:
                out[k]={'nome':nome,'inc':inc,'syn':syn,'sec':sec}
    return out
E=grab(14,716,'edhrec'); W=grab(716,1064,'wiki')
print('edhrec',len(E),'wiki',len(W))
json.dump({'edhrec':E,'wiki':W},open('edhrec.json','w'),ensure_ascii=False,indent=1)
for k,v in sorted(E.items(),key=lambda x:-x[1]['inc'])[:200]:
    print(f"{v['inc']:5.1f} {v['syn'] if v['syn'] is not None else '':>6} {v['nome']} [{v['sec'][:22]}]")

import json,sys
sys.path.insert(0,'/home/claude/edgar/scripts')
from motor import *
import dados
B='/home/claude/edgar/'
M=json.load(open(B+'sim_resultado.json')); S=json.load(open(B+'stats_versoes.json'))
pc=lambda x:f"{x*100:.0f}%"; d1=lambda x:f"{x:.1f}".replace('.',',')
h,f,a=M['hoje'],M['forte'],M['atalho']
L=[]; w=L.append
w("# Handover: Edgar Markov (Linhagem Markov)")
w("")
w("Versão 2, de 15/10/2026, depois da auditoria. Substitui a versão 1. Anexo de detalhe do Handover Mestre.")
w("")
w("**Arquivos:**")
w("")
for x in ["`analise-claude-edgar.md` (versão final, as duas partes)","`auditoria-edgar.md` (o que mudou da versão 1 e por quê)","`lista_forte_edgar.txt`","`lista_atalho_edgar.txt`","`cache_cartas_v2.4.json` (o mesmo da outra conversa; a auditoria não precisou de texto novo)","`scripts_edgar_v2.zip` (os scripts dela, com o simulador corrigido e os da auditoria)","`dados_edgar_edhrec_precon.md`"]: w("- "+x)
w("")
w("## Estado")
w("")
w("Análise completa e auditada, em reconstrução forte. O teste das dez mãos ainda não foi feito.")
w("")
w(f"| | Hoje | Forte ({len(dados.PARES)} trocas) | Atalho (10) |\n|---|---|---|---|")
w("| Nota (projetada) | 6,5 | 8,5 | 7,5 |")
w(f"| Placar | {S['atual']['placar']} | {S['forte']['placar']} | {S['atalho']['placar']} |")
w("| Game Changers / Bracket | 3 / B3 | 6 / B4 | 3 / B3 |")
w(f"| Vampiros em campo no turno 4 | {d1(h['vampiros_t4'])} | {d1(f['vampiros_t4'])} | {d1(a['vampiros_t4'])} |")
w(f"| Edgar em campo até o turno 6 | {pc(h['p_edgar_t6'])} | {pc(f['p_edgar_t6'])} | {pc(a['p_edgar_t6'])} |")
w(f"| Mesa morta até o turno 8 (goldfish) | {pc(h['p_mesa_t8'])} | {pc(f['p_mesa_t8'])} | {pc(a['p_mesa_t8'])} |")
w("")
w("Nome de painel sugerido: **Linhagem Markov**. Grupo provável: 01. Top.")
w("")
w("## O que ele disse")
w("")
for x in ["Foi o deck onde tudo começou; terá sempre um cantinho especial, e por isso ficou por último.",
"A força é a eminência. Ele quer estratégia e agrupamentos definitivos, os melhores Vampiros das três cores, e cartas muito sinérgicas.",
"\"Quero 10\", com o melhor esforço. Não se importa com Game Changers nem com bracket.",
"Plano A: horda no combate. Mesa casual, de jogos longos.",
"Sobre os Vampiros: os melhores, mas não mais do mesmo; nada previsível; tem que ter um porquê.",
"Mandou três listas de comparação: Beijo do Vampiro (de um amigo), JoeyDH (Archidekt) e WinterDragon (Moxfield).",
"Tem outros 3 ou 4 decks de Vampiros e vai montar mais um ou dois."]: w("- "+x)
w("")
w("## A conta")
w("")
w("**Conjurar, coroar, investir.** Cada Vampiro conjurado vale dois corpos. Cada lorde e cada ataque do Edgar somam +1 em todos. Em finanças: a eminência é bonificação em ações, e o lorde é o reajuste que incide sobre a base inteira. A eminência rende por mágica, não por mana, por isso Vampiro barato e mana cedo valem mais aqui.")
w("")
w("## Eixos (definitivos, criados na análise)")
w("")
w("Mana, Compra e busca, Remoção, Proteção, Eminência, Coroação, Investida e Banquete. Os oito passam no crivo.")
w("")
w("## O que não pode se perder")
w("")
for x in ["A eminência funciona da zona de comando e só com mágica **conjurada**. Changeling e loucura disparam; pôr no campo e a cópia preparada não.",
"O Edgar precisa estar na zona de comando ou em campo ao conjurar **e** ao resolver.",
"Isshin dobra o ataque do Edgar e o dreno do Seeker (regra oficial). Roaming Throne só dobra a eminência com o Edgar em campo (leitura).",
"Akroma's Will: os dois modos só com o Edgar em campo (regra 903.3d). O modo de voar e golpe duplo, que é o letal, funciona sem ele.",
"Olivia's Wrath mata o Isshin (Humano). Crippling Fear o deixa vivo.",
"Seeker, Isshin e Bloodletter juntos: 4 de cada oponente por Vampiro atacante, antes dos bloqueios. É o teto, não a rotina; as buscas apontam para ele.",
"Skullclamp não mata ficha com lorde em campo; com lorde, precisa de saída de sacrifício (Yahenni é a grátis).",
"Cemetery Gatekeeper: nunca exile carta de criatura, que ele queima você também.",
"Combo de reserva: Vito, Thorn of the Dusk Rose + Bloodthirsty Conqueror (Spellbook 314-6191); qualquer perda de vida de um oponente começa o laço."]: w("- "+x)
w("")
w("## Achados")
w("")
for x in ["**Mana.** 32 terrenos, nenhuma aceleração fora dos terrenos e 8 que entram virados. O Edgar em campo até o turno 6 em só "+pc(h['p_edgar_t6'])+" das partidas.",
"**A horda gera e não converte.** Só três cartas atravessam bloqueio, e não há dreno por atacante.",
"**Toxic Deluge mata a própria horda.** No Clavileño é S porque lá a morte é o motor; aqui a horda é o capital.",
"**2026 trouxe Vampiros preparados:** Emeritus of Woe (Demonic Tutor repetível, sem ser Game Changer), Stensian Sanguinist (Exsanguinate repetível) e Scheming Silvertongue (Sign in Blood).",
"**A lista dele é a menos previsível do grupo:** 36 cartas, fora os básicos, não aparecem em nenhum dos três decks de comparação."]: w(f"{x}" if False else "- "+x)
w("")
w("## Onde discordei")
w("")
for x in ["A forte fica um pouco mais previsível na média dos Vampiros: saem Vampiros raros que rendem pouco e entram Sanctum Seeker e Indulgent Aristocrat, que não têm substituta à altura.",
"Tier alto não é meta: S é o que o plano não substitui. A forte tem 7 cartas S.",
"Coat of Arms e Kindred Charge saem para duas pedras, pela simulação. Se a mesa dele não tiver outras tribais, o Coat volta no lugar do Talisman of Indulgence."]: w("- "+x)
w("")
w(f"## Trocas\n\n**Forte: {len(dados.PARES)} trocas em {len(set(p[2] for p in dados.PARES))} camadas.** O atalho são as 10 marcadas com asterisco.\n")
for cam in sorted(set(p[2] for p in dados.PARES)):
    w(f"- **{dados.CAMADAS[cam]}:**")
    for sai,entra,c,at in dados.PARES:
        if c==cam: w(f"  - {sai} → {entra}{'*' if at else ''}{' (Game Changer)' if 'GC' in D[entra]['flags'] else ''}")
w("")
w("## Aberto (com a opção que recomendo)")
w("")
for x in ["**Forte ou atalho?** Recomendo a forte, porque ele liberou o bracket. O atalho fica como a versão B3 para mesas que pedirem.",
"**Coat of Arms:** fica fora, a menos que a mesa dele não tenha outras tribais.",
"**Pets que rendem pouco** (Cemetery Gatekeeper, Vampire Nocturnus, Lich-Knights' Conquest): ficam. Se um dia ele liberar um, a vaga vai para um Vampiro de 1 ou 2 manas.",
"**Nome de painel:** Linhagem Markov, Coroação de Sangue ou A Corte do Patriarca.",
"**Teste das dez mãos da forte:** 3 Vampiros no turno 4 em seis mãos; Edgar até o turno 6 em quatro; mesa morta ou combo até o turno 8 em cinco; nenhuma mão travada em dois terrenos."]: w(f"{x}" if False else "- "+x)
w("")
w("## Painel")
w("")
w("**Clima:** galeria de retratos de família em Innistrad. **Paleta:** Verniz-âmbar #8C5A2B, Veludo-ameixa #4A1F3D, Prata-de-castiçal #C9C6BF, Carvão-de-lareira #1B1A1F, Sinete-carmim #9E1B32. **Moldura:** retrato oval com filete dourado. **Motivo:** árvore genealógica que ganha um ramo para cada Vampiro.")
w("")
w("## Para o Mestre (v2.4)")
w("")
w("Ver a última seção de `auditoria-edgar.md`. Em resumo: pergunta sempre com opção recomendada; lista de tarefas atualizada; fatias de 30 minutos com arquivo; auditoria por outra conversa no modo profundo; regra 903.3d no passo 2; efeito de X gasta a mana no simulador; decisão de mana só pela simulação.")
open(B+'final/Handover_Edgar_Analise_de_Deck.md','w').write('\n'.join(L)+'\n'); print('handover ok')

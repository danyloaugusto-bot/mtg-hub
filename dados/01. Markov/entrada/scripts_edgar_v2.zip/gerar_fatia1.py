import sys,json; sys.path.insert(0,'/home/claude/edgar/scripts')
from motor import *
from dados import NOMES_EIXOS
S=json.load(open(BASE+'stats_versoes.json'))
C=json.load(open(BASE+'comparacao/resumo.json'))['res']
A=atual(); F=montar(A,PARES); AT=montar(A,[p for p in PARES if p[3]])
import re
def parse(f):
    out=set()
    for l in open(f):
        l=l.strip()
        if not l or l[0] in '#/': continue
        m=re.match(r'^(\d+)\s+(.+)$',l); out.add(norm(m.group(2)))
    return out
BJ0=parse(BASE+'comparacao/beijo.txt')
tres=parse(BASE+'comparacao/beijo.txt')|parse(BASE+'comparacao/joey.txt')|parse(BASE+'comparacao/winter.txt')
basic={'plains','swamp','mountain'}
excl=lambda L: sorted({x for x in L if norm(x) not in tres and norm(x) not in basic and x!='Edgar Markov'})
EXH,EXF=excl(A),excl(F)
BJ={x for x in set(A)|set(F) if norm(x) in BJ0 and norm(x) not in basic and x!='Edgar Markov'}
def pct(x):
    i=inc(x); return '—' if i is None else f"{i:.0f}"
def linha(x):
    d=D[x]; n=d['n']; pet=' (pet)' if 'PET' in d['flags'] else ''
    return f"| {x}{pet} | {d['mv']} | "+" | ".join(str(n[e]) for e in EIXOS)+f" | {d['tier']} | {d['rel']} | {pct(x)} | {d['porque']} |"
cab="| Carta | MV | "+" | ".join(EIXOS)+" | Tier | Relev. | EDHREC % | Por quê, neste comandante |\n|---|---|"+"---|"*8+"---|---|---|---|"
cards=sorted(set(A)-{'Edgar Markov'},key=lambda x:(-'SABCD'.index(D[x]['tier']) if False else 'SABCD'.index(D[x]['tier']),x))
crit=[x for x in cards if D[x]['tipo']=='C']; outr=[x for x in cards if D[x]['tipo']=='O']; terr=[x for x in cards if D[x]['tipo']=='L']
def sv(k,fmt='{}'): return ' | '.join(fmt.format(S[v][k]) for v in ['atual','forte','atalho'])
pares_txt=[]
for cam in sorted(CAMADAS):
    pares_txt.append(f"\n**Camada {cam}. {CAMADAS[cam]}**\n\n| Sai | Entra | No atalho | Por quê |\n|---|---|---|---|")
    for sai,entra,c_,at in PARES:
        if c_!=cam: continue
        pares_txt.append(f"| {sai} ({D[sai]['tier']}, EDHREC {pct(sai)}) | {entra} ({D[entra]['tier']}, EDHREC {pct(entra)}) | {'sim' if at else 'não'} | {D[entra]['porque']} |")
out=open(BASE+'analise-claude-edgar_fatia1.md','w')
w=lambda s='': out.write(s+'\n')
w("# Análise final: Linhagem Markov (Edgar Markov)")
w()
w("Analista: Claude | Data: 15/10/2026 | Lista conferida por script: 100 cartas, 16 pets (com o comandante), nenhuma repetida | Cartas sem texto conferido: nenhuma. Texto conferido nesta conversa: 231 cartas no EDHREC e no Archidekt, mais 11 do cache v2.3; regras no Grimoria; combos no Commander Spellbook.")
w()
w("Versão final, revista na auditoria de 15/10/2026 (o que mudou está em `auditoria-edgar.md`). As notas são projeção sem partida.")
w()
w("## Nota de partida")
w()
w("| | Hoje | Forte | Atalho (10 trocas) |\n|---|---|---|---|")
w("| Nota | 6,5 | 8,5 (projetada) | 7,5 (projetada) |")
w(f"| Placar | {S['atual']['placar']} | {S['forte']['placar']} | {S['atalho']['placar']} |")
w(f"| Game Changers | {len(S['atual']['gc'])} | {len(S['forte']['gc'])} | {len(S['atalho']['gc'])} |")
w("| Bracket | 3 | 4 | 3 |")
w()
w("**A descoberta principal.** O deck gera muito bem e converte por poucos caminhos, e ainda chega atrasado. A eminência e os lordes fazem a horda. Mas a mana não tem nenhuma aceleração fora dos terrenos, e 8 dos 32 terrenos entram virados. Com isso, o Edgar de 6 manas, que é quem coroa a horda, chega tarde. E na hora de atravessar bloqueio a lista tem só três cartas: Cover of Darkness, Shared Animosity e Akroma's Will. Falta quem transforme cada atacante em dano mesmo bloqueado (Sanctum Seeker) e quem dobre os gatilhos de ataque (Isshin).")
w()
w("**A segunda descoberta veio de 2026.** Secrets of Strixhaven e Reality Fracture trouxeram Vampiros \"preparados\", que carregam uma mágica de reserva. O Emeritus of Woe é um Vampiro de 4 manas que entra com um Demonic Tutor pronto e o recarrega a cada turno com duas mortes, e não é Game Changer. O Stensian Sanguinist é um Vampiro de 2 manas que vira um Exsanguinate sempre que a horda conecta. Quase ninguém joga essas cartas no Edgar: o Emeritus está em 25% dos decks no EDHREC, e o Sanguinist fica abaixo do corte da lista (14% no edh.wiki).")
w()
w("**Como li o pedido.** Reconstrução forte. Você quer 10, pediu o melhor esforço e liberou Game Changers e combos. O plano A é a horda no combate, o plano B é o dreno com o combo do Vito, e a mesa é casual, de jogos longos. Vampiro previsível só entra quando não tem substituta à altura, e cada escolha vem com o motivo.")
w()
w("**Por que não 10.** São três tetos honestos:")
w()
w("- O Edgar custa 6, e metade do valor dele (os marcadores do ataque) só vem com ele em campo.")
w("- 16 pets ocupam espaço, e três deles rendem pouco aqui: Cemetery Gatekeeper, Vampire Nocturnus e Lich-Knights' Conquest.")
w("- A lista nunca foi embaralhada. A nota da forte é projeção até o teste das dez mãos.")
w()
w("## 1. Plano")
w()
w("### A leitura do Edgar")
w()
w("| Trecho | O que o texto diz | Regra oficial ou leitura | O que muda no deck |\n|---|---|---|---|")
w("| Eminência | \"Whenever you cast another Vampire spell, if Edgar is in the command zone or on the battlefield, create a 1/1 black Vampire creature token.\" | Regra oficial (Grimoria): é gatilho, e o Edgar precisa estar na zona de comando ou em campo quando você conjura e de novo quando o gatilho resolve. Se ele troca de zona no meio, o gatilho não faz nada. Roaming Throne só dobra a eminência com o Edgar em campo (leitura minha: na zona de comando ele não é \"creature you control\"). | Do turno 1 em diante, cada Vampiro conjurado vale dois corpos. O Edgar não precisa ser conjurado para o motor andar. |")
w("| \"Cast\" | Conjurar, não pôr. | Regra 16 do Mestre. | Não disparam: o que Descendants' Fury, Lich-Knights' Conquest e a Olivia, Crimson Bride põem em campo, as fichas da Elenda e a cópia preparada do Emeritus (é um feitiço). Disparam: changelings (Mirror Entity) e a loucura do Markov Baron. |")
w("| \"Another\" | O próprio Edgar não conta. | Texto. | Conjurar o Edgar não gera ficha. |")
w("| First strike, haste | Ataca no turno em que entra. | Texto. | Com 6 manas, ele entra e coroa a horda no mesmo turno. |")
w("| Ataque | \"Put a +1/+1 counter on each Vampire you control.\" | Texto. Isshin dobra (regra oficial: vale para gatilhos ligados a ataque), e Roaming Throne também. | Marcador é permanente: cada ataque é um reajuste que fica. |")
w("| \"If you control a commander\" | Akroma's Will escolhe os dois modos se você controla um comandante. | Regra oficial 903.3d: controlar um comandante quer dizer tê-lo em campo. | Sem o Edgar em campo, a Akroma's Will escolhe um modo só. O modo do letal (voar e golpe duplo) não precisa dele. |")
w()
w("### A conta")
w()
w("**Conjurar, coroar, investir.** Cada Vampiro conjurado vale dois corpos. Cada lorde e cada ataque do Edgar somam +1 em todos eles.")
w()
w("Poder da horda ≈ 2N × (1 + L + k), onde N é o número de Vampiros conjurados, L o número de lordes e k o número de ataques do Edgar. No turno 6, com N = 7, L = 2 e k = 1, são 14 corpos de 4 de poder: 56 de dano potencial.")
w()
w("Em finanças, a eminência é uma bonificação em ações: cada compra vem com uma ação extra. O lorde e o ataque do Edgar são reajustes que incidem sobre a base inteira, bonificadas incluídas. Por isso o deck precisa de base larga cedo: o retorno de um lorde cresce com a base sobre a qual ele incide.")
w()
w("### Onde a lista trai o plano, em ordem de gravidade")
w()
w(f"1. **Mana.** Nenhuma aceleração fora dos terrenos, {S['atual']['tap']} terrenos que entram virados, e Temple of the False God e Valgavoth's Lair quase não pagam. O Edgar chega tarde, e com ele o coroar.")
w("2. **A horda não atravessa.** Contra bloqueio, a lista só tem Cover of Darkness, Shared Animosity e Akroma's Will. Falta o dreno por atacante (Sanctum Seeker), quem dobre os gatilhos de ataque (Isshin) e quem torne o ataque seguro (Iroas).")
w("3. **Limpeza que mata a própria horda.** O Toxic Deluge não poupa ninguém, e numa mesa casual a limpeza unilateral rende mais (Crippling Fear, Olivia's Wrath, Ruinous Ultimatum).")
w("4. **Cartas que não entram na conta.** Descendants' Fury põe, não conjura. Bloodlord of Vaasgoth pede dano antes de você conjurar. O persist do Dusk Legion Sergeant só vale para Vampiros que não são ficha. Faithless Looting perde carta. Blood for the Blood God! e March of the Canonized custam caro pelo que dão.")
w("5. **Akroma's Will com um modo só** enquanto o Edgar estiver na zona de comando (regra 903.3d). O modo de golpe duplo, que é o letal, funciona sozinho.")
w()
w("### As três fases")
w()
w("| Fase | Objetivo | Como | Cartas que decidem |\n|---|---|---|---|")
w("| Início (turnos 1 a 4) | Base larga: 6 a 8 corpos no turno 4 | Vampiro de 1 e 2 manas com a eminência da zona de comando; um motor de compra cedo | Indulgent Aristocrat, Legion Lieutenant, Cordial Vampire, Skullclamp, Welcoming Vampire, Sol Ring |")
w("| Meio (turnos 5 a 7) | Coroar e converter | Lordes; Edgar com ímpeto; transformar fichas em cartas e cada ataque em dreno | Edgar, Stromkirk Captain, Captivating Vampire, Sanctum Seeker, Isshin, Emeritus of Woe, Pact of the Serpent |")
w("| Fim (turno 7 em diante) | Fechar a mesa, não um jogador | Investida com pump ou cópia; dreno dobrado; o combo do Vito como reserva | Shared Animosity, Akroma's Will, Kindred Charge, Bloodletter of Aclazotz, Stensian Sanguinist, Vito + Conqueror |")
w()
w("**Mão inicial.** Fique com 2 a 4 terrenos, sendo duas cores desviradas, pelo menos um Vampiro de até 2 manas e um motor (Skullclamp, Welcoming Vampire ou um lorde). Faça mulligan com zero Vampiros de até 3 manas ou com um terreno só.")
w()
w("## 2. Agrupamentos")
w()
w("Você pediu agrupamentos definitivos; estes oito passam no crivo. Cada um mede uma função, eles se somam, cada um tem mais de seis cartas, e há eixo para proteção, que faltou em quase todos os decks até hoje.")
w()
w("| Eixo | O que mede | 3 é | Cartas com nota 2 ou 3 (hoje / forte / atalho) |\n|---|---|---|---|")
desc={'MAN':('Ramp e fixação de cor','Sol Ring, Command Tower'),'CMP':('Compra e busca','Skullclamp, Emeritus'),'REM':('Remoção, pontual e em massa','Olivia\'s Wrath'),'PRO':('Proteção da horda e do Edgar','Teferi\'s Protection'),'EMI':('Eminência: corpos por mágica (Vampiro barato, ficha, dobrador)','Vampiro de 1 ou 2 manas, Anointed Procession'),'COR':('Coroação: lordes e marcadores permanentes','Legion Lieutenant, Cordial Vampire'),'INV':('Investida: fechar em combate (evasão, pump de turno, dreno por atacante)','Shared Animosity, Sanctum Seeker'),'BAN':('Banquete: sacrifício, dreno na morte, combo de reserva','Blood Artist, Vito')}
for e in EIXOS:
    w(f"| {NOMES_EIXOS[e]} ({e}) | {desc[e][0]} | {desc[e][1]} | {sv('n_'+e)} |")
w()
w("O placar não ganha bônus de pet, porque esse bônus é do eixo Sinergia, que aqui não existe. Pets nunca saem, de qualquer forma.")
w()
w("## 3. Carta a carta")
w()
w("Notas de 0 a 3 por eixo. \"EDHREC %\" é a inclusão nos 51.835 decks do Edgar; \"—\" quer dizer abaixo do corte das listas, ou seja, rara. Ordem: tier, depois nome.")
w()
w(f"### Criaturas ({len(crit)})\n"); w(cab)
for x in crit: w(linha(x))
w(f"\n### Outras mágicas e artefatos ({len(outr)})\n"); w(cab)
for x in outr: w(linha(x))
w(f"\n### Terrenos ({len(terr)} nomes, {S['atual']['terrenos']} cartas)\n"); w(cab)
for x in terr: w(linha(x))
w()
w("## 4. Diagnóstico")
w()
w("| Medida | Hoje | Forte | Atalho | Faixa |\n|---|---|---|---|---|")
w(f"| Terrenos | {sv('terrenos')} | 35 a 37 (abaixo de propósito: curva baixa e eminência da zona de comando) |")
w(f"| CMC médio (sem terrenos) | {sv('cmc','{:.2f}')} | |")
w(f"| Terrenos que entram virados | {sv('tap')} | |")
w(f"| Ramp fora dos terrenos | {sv('ramp_nao_terreno')} | 10 a 12 (o deck vive abaixo disso de propósito) |")
w(f"| Compra e busca (nota 2+) | {sv('n_CMP')} | 10 a 12 |")
w(f"| Remoção (nota 2+) | {sv('n_REM')} | 8 a 12 |")
w(f"| Remoção em massa / unilateral | {S['atual']['massa']} / {S['atual']['unilateral']} | {S['forte']['massa']} / {S['forte']['unilateral']} | {S['atalho']['massa']} / {S['atalho']['unilateral']} | 3 a 5 |")
w(f"| Proteção (nota 2+) | {sv('n_PRO')} | |")
w(f"| Mágicas de Vampiro (disparam a eminência) | {sv('vampiros')} | |")
w(f"| Vampiros de 1 e 2 manas | {sv('vamp_mv12')} | |")
w(f"| Lordes | {sv('lordes')} | |")
w(f"| Tiers S / A / B / C / D | "+" | ".join('/'.join(str(S[v]['tiers'][t]) for t in 'SABCD') for v in ['atual','forte','atalho'])+" | Poucos S, zero D |")
w(f"| Placar (CMC {S['atual']['pts_cmc']} + aceleração {S['atual']['pts_acel']} + notas) | {sv('placar')} | |")
w()
w(f"A aceleração bate no teto de 90 nas três versões, porque os terrenos contam no eixo Mana. Quem diferencia o placar são as notas. O placar também não mede a velocidade do motor; isso fica para a simulação da fatia 2.")
w()
w("### Gerar contra converter")
w()
w("| | Gera | Converte |\n|---|---|---|")
w("| Hoje | 36 mágicas de Vampiro com eminência, 8 lordes | 3 cartas de evasão ou pump de turno, nenhum dreno por atacante, combo de reserva sem busca |")
w(f"| Forte | {S['forte']['vampiros']} mágicas de Vampiro, {S['forte']['lordes']} lordes, Isshin dobrando o ataque | Sanctum Seeker, Bloodletter, Stensian, Iroas, Shared Animosity, Akroma's Will, Kindred Charge, Mirror Entity, Coat of Arms; combo com três buscas |")
w()
w("### Previsibilidade, medida")
w()
w("Régua: o percentual de inclusão no EDHREC. Mede presença, não força.")
w()
w("| Deck | Vampiros | Vampiros com 50% ou mais | Inclusão média dos Vampiros | Game Changers |\n|---|---|---|---|---|")
for k in ['Danylo hoje','Danylo forte','Danylo atalho','Beijo do Vampiro','JoeyDH (Archidekt)','WinterDragon (Moxfield)']:
    r=C[k]; w(f"| {k} | {r['vamp']} | {r['vamp50']} | {r['vampmed']:.0f}% | {len(r['gc'])} |")
w()
w(f"Sua lista de hoje já é a menos previsível do grupo. {len(EXH)} cartas dela, fora os básicos, não aparecem em nenhum dos três decks. Na forte, a média dos Vampiros sobe de {C['Danylo hoje']['vampmed']:.0f}% para {C['Danylo forte']['vampmed']:.0f}%, e isso é escolha minha: saem Vampiros raros mas fracos (Bloodlord, Sergeant, Vito Fanatic, Carmen) e entram duas peças sem substituta à altura (Sanctum Seeker e Indulgent Aristocrat). A assinatura do deck muda de lugar: passa a ser o que só este Edgar tem, Isshin, Iroas, Stensian, Emeritus, Scheming Silvertongue, o Edgar de 2026, Crippling Fear e Three Tree City. Na forte, {len(EXF)} cartas não aparecem em nenhum dos três decks.")
w()
w(f"O Beijo do Vampiro, do seu amigo, é um Bracket 4 de sete Game Changers (Imperial Seal, Vampiric, Demonic, The One Ring, Necropotence, Citadel e Teferi's). Ele divide {len(set(A)&BJ)} cartas com a sua lista de hoje e {len(set(F)&BJ)} com a forte. A diferença de fundo: o Beijo busca peças, e a sua forte busca e também dobra o ataque.")
w()
w("### Combos")
w()
w("- **Vito, Thorn of the Dusk Rose + Bloodthirsty Conqueror** (Spellbook 314-6191). Com as duas em campo, qualquer perda de vida de um oponente (um ataque, um gatilho do Seeker ou do Blood Artist) começa o laço, e a mesa perde vida infinita. Já está na lista. Na forte, três buscas o encontram: Demonic, Vampiric e o Emeritus.")
w("- Peças possíveis que recusei: Exquisite Blood (314-3966) e Sanguine Bond (690-6191). Com três buscas, uma terceira peça não acrescenta.")
w("- **Brackets.** Hoje: Bracket 3, com 3 Game Changers e um combo de 8 manas que não é de começo de jogo. Forte: Bracket 4, com 6 Game Changers. Atalho: Bracket 3.")
w()
w("## 6. Trocas")
w()
w(f"Versão forte: {len(PARES)} trocas em {len(CAMADAS)} camadas (a camada 5 entrou com a simulação da fatia 2, e a camada 6 com a auditoria, que também devolveu o Vampire of the Dire Moon ao deck). O atalho são as 10 marcadas, escolhidas para continuar no Bracket 3 (nenhum Game Changer novo). A fatia 2 mede o motor de cada versão e pode mexer no atalho.")
for t in pares_txt: w(t)
w()
w("### Banco (entram se você quiser outra cara)")
w()
w("| Carta | Por quê | EDHREC % |\n|---|---|---|")
banco=[("Vampires' Vengeance","Instantânea de 3: 2 de dano em tudo que não é Vampiro. A limpeza unilateral mais barata da tribo.","7"),
("Lethal Scheme","Remoção instantânea paga por fichas (convocar), e cada ficha que pagou conspira.","—"),
("Bloodline Recollector","Reality Fracture: Vampiro de 2 que vira Ancestral Craving (compra 3) a cada fim de turno com três mortes.","5"),
("Oathsworn Vampire","Volta do cemitério para ser conjurado de novo quando você ganhou vida: eminência repetível.","21"),
("Door of Destinies","Cresce a cada mágica de Vampiro, o mesmo evento da eminência.","—"),
("Taunt from the Rampart","Uma rodada sem bloqueadores na mesa inteira: letal com a horda.","—"),
("Enlightened Tutor","Busca Skullclamp, Shared Animosity, Anointed Procession ou Necropotence (Game Changer).","12"),
("Changeling Outcast","Changeling de 1 mana que não pode ser bloqueado: dispara a eminência e carrega os marcadores.","—"),
("Dusk Legion Duelist","Compra quando recebe marcador: cada ataque do Edgar vira carta.","—")]
for b in banco: w(f"| {b[0]} | {b[1]} | {b[2]} |")
w()
w("### Recusadas")
w()
w("| Carta | Por quê |\n|---|---|")
rec=[("Champion of Dusk","Compra e perde X obrigatoriamente; com 15 Vampiros, 15 de vida de uma vez."),
("Charismatic Conqueror, Viscera Seer, Master of Dark Rites, Malakir Bloodwitch, Twilight Prophet","Previsíveis (46% a 61%) e com substituta melhor na lista ou na forte."),
("Vein Ripper, Patron of the Vein, Necropolis Regent, Crossway Troublemakers","Seis manas disputando o turno com o Edgar."),
("Mondrak, Glory Dominus e Ojer Taq","Dobram fichas como o Anointed Procession, mas não são Vampiros nem disparam a eminência."),
("Maskwood Nexus","Quatro manas para tornar Vampiro o que já quase todo é."),
("The One Ring e Mox Diamond","Game Changers fortes, mas o deck já compra demais, e a Mox custa uma carta num jogo longo."),
("Exquisite Blood e Sanguine Bond","Terceira peça de combo; as buscas já acham o Vito e o Conqueror."),
("Bloodline Bidding e Kindred Judgment","Oito e sete manas; a primeira põe, não conjura."),
("Toxic Deluge (sai)","Mata a horda junto. No Clavileño é S porque lá a morte é o motor; aqui a horda é o capital."),
("Edgar, Ancient Bloodlord","Proposto na fatia 1. A auditoria mediu e ele rende menos que o Vampire of the Dire Moon, que ele tirava; é um B que entrava pelo nome."),
("Coat of Arms e Kindred Charge (saem)","Finalizadores que a simulação troca com vantagem por duas pedras de mana. O Coat ainda é simétrico numa mesa de tribais.")]
for r in rec: w(f"| {r[0]} | {r[1]} |")
w()
w("## 8. Dúvidas (parcial)")
w()
w("- A Akroma's Will com um modo só, com o Edgar na zona de comando, é regra oficial (903.3d), conferida na auditoria.")
w("- O Roaming Throne não dobra a eminência com o Edgar na zona de comando. Também é leitura minha, pelo texto \"another creature you control\".")
w("- Cemetery Gatekeeper (pet): nunca exile carta de criatura, terreno ou feitiço. Exile instantâneo ou planeswalker de um oponente.")
w("- A previsibilidade usa a inclusão do EDHREC. Carta abaixo do corte das listas conta como zero.")
out.close()
print('ok', len(EXH), len(EXF))

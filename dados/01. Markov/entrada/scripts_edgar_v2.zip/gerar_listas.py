import sys,json; sys.path.insert(0,'/home/claude/edgar/scripts')
from motor import *
info={c['nome']:c for c in LISTA}
def escrever(L,arq):
    linhas=['COMMANDER','1 Edgar Markov (C17) 36 *F*','']
    for x in sorted(set(L)-{'Edgar Markov'}):
        q=L.count(x); c=info.get(x)
        if c: linhas.append(f"{q} {x} ({c['set']}) {c['num']}"+(' *F*' if c['pet'] else ''))
        else: linhas.append(f"{q} {x}  [nova]")
    open(BASE+arq,'w').write('\n'.join(linhas)+'\n')
A=atual(); F=montar(A,PARES); AT=montar(A,[p for p in PARES if p[3]])
escrever(F,'lista_forte_edgar.txt'); escrever(AT,'lista_atalho_edgar.txt')
print(sum(1 for l in open(BASE+'lista_forte_edgar.txt') if '[nova]' in l), sum(1 for l in open(BASE+'lista_atalho_edgar.txt') if '[nova]' in l))

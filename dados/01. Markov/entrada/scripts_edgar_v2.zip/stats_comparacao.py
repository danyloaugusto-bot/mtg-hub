import sys,json,re; sys.path.insert(0,'/home/claude/edgar/scripts')
from motor import *
T=json.load(open(BASE+'textos.json'))
def parse(f):
    out=[]
    for l in open(f):
        l=l.strip()
        if not l or l.startswith('#') or l.startswith('//'): continue
        m=re.match(r'^(\d+)\s+(.+)$',l); out+= [m.group(2).strip()]*int(m.group(1))
    return out
# precon 2017 da seção 3 do arquivo de dados
P=[];sec=False
for l in open(BASE+'textos/dados_edgar.md'):
    if l.startswith('## 3.'): sec=True; continue
    if sec and l.startswith('## 4.'): break
    m=re.match(r'^(\d+)\s+(.+?)\s*$',l.strip())
    if sec and m: P+= [m.group(2)]*int(m.group(1))
GCN=set()
sec=False
for l in open(BASE+'textos/dados_edgar.md'):
    if l.startswith('### Lista completa dos 53'): sec=True; continue
    if sec and l.startswith('### '): break
    if sec:
        m=re.match(r'^[-*\d. ]*\**([^|*]+?)\**\s*\|',l)
        if m: GCN.add(norm(m.group(1)))
print('GC lidos da lista oficial:',len(GCN))
decks={'Beijo do Vampiro':parse(BASE+'comparacao/beijo.txt'),'JoeyDH (Archidekt)':parse(BASE+'comparacao/joey.txt'),'WinterDragon (Moxfield)':parse(BASE+'comparacao/winter.txt'),'Precon 2017':P}
A=atual(); F=montar(A,PARES); AT=montar(A,[p for p in PARES if p[3]])
decks.update({'Danylo hoje':A,'Danylo forte':F,'Danylo atalho':AT})
basic={'plains','swamp','mountain','island','forest'}
def isvamp(n):
    if n in D: return 'V' in D[n]['flags']
    t=T.get(n) or {}
    return 'Vampire' in (t.get('tipo') or '') or 'Changeling' in (t.get('oracle') or '')
def island(n):
    if n in D: return D[n]['tipo']=='L'
    t=T.get(n) or {}
    tp=(t.get('tipo') or '')
    return tp.startswith('Land') or (' Land' in tp and '//' not in tp)
res={}
for k,L in decks.items():
    nc=[x for x in L if norm(x)!='edgar markov']
    vamps=[x for x in nc if isvamp(x)]
    nonl=[x for x in nc if norm(x) not in basic and not island(x)]
    iv=[inc(x) or 0 for x in vamps]
    gc=sorted({x for x in nc if norm(x) in GCN})
    res[k]=dict(n=len(L),vamp=len(vamps),vamp50=sum(1 for i in iv if i>=50),vampmed=sum(iv)/max(1,len(iv)),
                nl50=sum(1 for x in nonl if (inc(x) or 0)>=50),gc=gc)
    print(f"{k:24} n={len(L)} vampiros={len(vamps):2} vamp>=50%={res[k]['vamp50']:2} media_vamp={res[k]['vampmed']:5.1f} naoterreno>=50%={res[k]['nl50']:2} GC={len(gc)} {gc}")
# sobreposição com o Beijo
B=set(decks['Beijo do Vampiro']); 
for k in ['Danylo hoje','Danylo forte']:
    s=set(decks[k])-{'Edgar Markov','Swamp','Plains','Mountain'}
    print(k,'em comum com o Beijo:',len(s&B))
print('Precon cartas',len(P))
json.dump({'precon':P,'res':res},open(BASE+'comparacao/resumo.json','w'),ensure_ascii=False,indent=1)

# sim_motor.py — goldfish guloso do Edgar: 20 mil partidas por versão, na jogada, sem mulligan, sem oponente.
import sys,random,json,re,statistics; sys.path.insert(0,'/home/claude/edgar/scripts')
from motor import *
T=json.load(open(BASE+'textos.json'))
CUSTO_CACHE={"Chaos Warp":"{2}{R}","Faithless Looting":"{R}","Idol of Oblivion":"{2}","Roaming Throne":"{4}","Shared Animosity":"{2}{R}","Skullclamp":"{1}","Sol Ring":"{1}","Arcane Signet":"{2}","Talisman of Hierarchy":"{2}","Talisman of Indulgence":"{2}","Talisman of Conviction":"{2}","Orzhov Signet":"{2}","Rakdos Signet":"{2}","Boros Signet":"{2}","Fellwar Stone":"{2}","Mind Stone":"{2}","Black Market Connections":"{2}{B}","Vampire of the Dire Moon":"{B}"}
def custo(n):
    s=CUSTO_CACHE.get(n) or (T.get(n) or {}).get('custo') or ''
    pips={'W':0,'B':0,'R':0}; gen=0; X=False
    for t in re.findall(r'\{([^}]+)\}',s):
        if t in pips: pips[t]+=1
        elif t.isdigit(): gen+=int(t)
        elif t=='X': X=True
    return pips,gen
# terrenos: (cores, regra de entrada) ; 'V' = qualquer cor só para Vampiro
TER={"Arid Mesa":("WR",'u'),"Blightstep Pathway":("BR1",'u'),"Brightclimb Pathway":("WB1",'u'),"Command Tower":("WBR",'u'),"Crystal Grotto":("C",'u'),
"Dragonskull Summit":("BR",'chk'),"Exotic Orchard":("WBR",'u'),"Fabled Passage":("WBR1",'t4'),"Fetid Heath":("WB",'u'),"Fountainport":("C",'u'),"Graven Cairns":("BR",'u'),
"Luxury Suite":("BR",'u'),"Mountain":("R",'u'),"Needleverge Pathway":("WR1",'u'),"Nomad Outpost":("WBR",'t'),"Path of Ancestry":("WBR",'t'),"Plains":("W",'u'),"Rugged Prairie":("WR",'u'),
"Savai Triome":("WBR",'t'),"Secluded Courtyard":("V",'u'),"Shattered Landscape":("WBR1",'t'),"Swamp":("B",'u'),"Temple of Malice":("BR",'t'),"Temple of Silence":("WB",'t'),
"Temple of Triumph":("WR",'t'),"Temple of the False God":("CC5",'u'),"Unclaimed Territory":("V",'u'),"Valgavoth's Lair":("B",'t'),"Vault of the Archangel":("C",'u'),"Voldaren Estate":("V",'u'),
"Windbrisk Heights":("W",'t'),"Blood Crypt":("BR",'u'),"Godless Shrine":("WB",'u'),"Sacred Foundry":("WR",'u'),"Marsh Flats":("WBR",'u'),"Bloodstained Mire":("WBR",'u'),"Three Tree City":("TTC",'u'),"Cavern of Souls":("V",'u'),"Vault of Champions":("WB",'u')}
CFG={}
TUTOR_PRI=["Skullclamp","Shared Animosity","Isshin, Two Heavens as One","Sanctum Seeker","Anointed Procession","Legion Lieutenant","Stromkirk Captain","Captivating Vampire","Welcoming Vampire"]
LORDS={"Captivating Vampire":1,"Legion Lieutenant":1,"Stromkirk Captain":1,"Markov Baron":1,"Edgar, Charmed Groom":1}
PRI_PRE=["Sol Ring","Arcane Signet","Talisman of Hierarchy","Talisman of Indulgence","Talisman of Conviction","Orzhov Signet","Rakdos Signet","Boros Signet","Fellwar Stone","Mind Stone","Black Market Connections","Skullclamp","Smothering Tithe","Anointed Procession","Isshin, Two Heavens as One","Roaming Throne","Shared Animosity","Coat of Arms","Idol of Oblivion","Necropotence","Legion's Landing"]
# no goldfish não há alvo nem limpeza: remoção, proteção e reanimação ficam na mão
SEM_ALVO={'Vampire Socialite',"Akroma's Will",'Kindred Charge',"Teferi's Protection",'Clever Concealment','Anguished Unmaking','Chaos Warp','Damn','Rite of Oblivion',"Olivia's Wrath",'Crippling Fear','Toxic Deluge','New Blood','Ruinous Ultimatum','Invasion of New Capenna',"Your Temple Is Under Attack","Lich-Knights' Conquest",'Blood for the Blood God!'}
def eh_vamp(n): return 'V' in D[n]['flags']
class Jogo:
    def __init__(s,deck,seed,log=False):
        s.r=random.Random(seed); s.lib=[x for x in deck if x!='Edgar Markov']; s.r.shuffle(s.lib)
        s.hand=[s.lib.pop() for _ in range(7)]; s.lands=[]; s.perm=set(); s.cri=[]; s.edgar=False; s.edgar_t=None
        s.dano=0; s.vistas=7; s.morreu_turno=0; s.tesouro=0; s.tithe=False; s.log=log; s.L=[]; s.kill=None; s.combo=None
        s.keeper_lord=False; s.banner=0; s.ganhou_vida=False; s.topo=[]; s.linha=None; s.linha_i=None
    def p(s,*a):
        if s.log: s.L.append(' '.join(str(x) for x in a))
    def draw(s,n=1):
        for _ in range(n):
            if s.topo: s.hand.append(s.topo.pop()); s.vistas+=1
            elif s.lib: s.hand.append(s.lib.pop()); s.vistas+=1
    # ---------- mana ----------
    def fontes(s,turno):
        F=[]; nl=len(s.lands); ttc=False
        for nome,tap in s.lands:
            cores,_=TER[nome]
            if tap: continue
            if cores=='CC5':
                if nl>=5: F+=[('C',),('C',)]
            elif cores=='TTC': ttc=True
            elif cores=='V': F.append(('V',))
            elif cores.endswith('1'): F.append(tuple(cores[:-1]))
            else: F.append(tuple(cores))
        if 'Sol Ring' in s.perm: F+=[('C',),('C',)]
        if 'Arcane Signet' in s.perm: F.append(tuple('WBR'))
        for _t,_c in (('Talisman of Hierarchy','WB'),('Talisman of Indulgence','BR'),('Talisman of Conviction','WR'),('Fellwar Stone','WBR')):
            if _t in s.perm: F.append(tuple(_c))
        if 'Mind Stone' in s.perm: F.append(('C',))
        for _t,_c in (('Orzhov Signet','WB'),('Rakdos Signet','BR'),('Boros Signet','WR')):
            if _t in s.perm and len(F)>=1: F.sort(key=lambda f:(f[0]!='C',len(f))); del F[0]; F+=[tuple(_c),tuple(_c)]
        F+=[('T',)]*s.tesouro
        if ttc:
            v=sum(1 for c in s.cri if c['v'])
            if v>=4 and len(F)>=2:
                F.sort(key=lambda f:(f[0] not in ('C','V'),len(f))); del F[:2]; F+=[('B',)]*v
            else: F.append(('C',))
        return F
    def pagar(s,F,pips,gen,vamp):
        usados=set()
        def pode(f,cor):
            if f[0]=='V': return vamp
            if f[0]=='T': return True
            return cor in f
        need=[c for c in 'WBR' for _ in range(pips[c])]
        need.sort(key=lambda c: sum(1 for f in F if pode(f,c)))
        for cor in need:
            cand=[i for i,f in enumerate(F) if i not in usados and pode(f,cor)]
            if not cand: return None
            cand.sort(key=lambda i:(F[i][0]=='T', len(F[i]) if F[i][0] not in ('V',) else 0))
            usados.add(cand[0])
        livres=[i for i in range(len(F)) if i not in usados]
        if len(livres)<gen: return None
        livres.sort(key=lambda i:(F[i][0]=='T', 0 if F[i][0] in ('C','V') else len(F[i])))
        usados|=set(livres[:gen])
        return usados
    def custo_total(s,n):
        pips,gen=custo(n)
        return pips,gen
    def jogar_terreno(s,turno):
        terr=[x for x in s.hand if D[x]['tipo']=='L']
        if not terr: return
        def entra_virado(x):
            r=TER[x][1]
            if r=='t': return True
            if r=='t4': return len(s.lands)<3
            if r=='chk': return not any(n in ("Swamp","Mountain","Savai Triome","Blood Crypt","Godless Shrine","Sacred Foundry","Marsh Flats","Bloodstained Mire","Arid Mesa") for n,_ in s.lands)
            return False
        # prefere virado quando não há o que fazer com a mana extra
        baratos=[x for x in s.hand if D[x]['tipo']!='L' and D[x]['mv']<=len(s.lands)+1]
        virados=[x for x in terr if entra_virado(x)]
        desvirados=[x for x in terr if not entra_virado(x)]
        if virados and (not baratos or not desvirados): esc=virados[0]
        elif desvirados:
            desvirados.sort(key=lambda x:-len(TER[x][0])); esc=desvirados[0]
        else: esc=terr[0]
        s.hand.remove(esc); s.lands.append([esc,entra_virado(esc)]); s.p(f"T{turno} terreno {esc}{' (virado)' if entra_virado(esc) else ''}")
    # ---------- efeitos ----------
    def criar_fichas(s,n,turno,origem):
        if 'Anointed Procession' in s.perm: n*=2
        for _ in range(n): s.cri.append(dict(n='ficha',pw=1,v=True,sick=True,cnt=0,ll=False,tok=True))
        s.fichas_turno+=n
        if n and 'Baron Bertram Graywater' in s.perm and not s.baron_usado:
            s.baron_usado=True; k=2 if 'Roaming Throne' in s.perm else 1
            m=k*(2 if 'Anointed Procession' in s.perm else 1)
            for _ in range(m): s.cri.append(dict(n='ficha',pw=1,v=True,sick=True,cnt=0,ll=True,tok=True))
            s.fichas_turno+=m
    def conjurar(s,n,turno):
        d=D[n]; s.hand.remove(n); s.p(f"T{turno} conjura {n}")
        if n=='Edgar Markov':
            s.edgar=True; s.edgar_t=turno
            s.cri.append(dict(n=n,pw=4,v=True,sick=False,cnt=0,ll=False,tok=False)); return
        if d['tipo']=='C':
            pw=(d['pt'] or (1,1))[0]
            s.cri.append(dict(n=n,pw=pw,v=eh_vamp(n),sick=True,cnt=0,ll=n in ("Gifted Aetherborn","Vampire of the Dire Moon","Scheming Silvertongue","Indulgent Aristocrat","Markov Baron","Elenda, the Dusk Rose","Nighthawk Scavenger"),tok=False))
            s.perm.add(n)
            if eh_vamp(n):
                k=1
                if s.edgar and 'Roaming Throne' in s.perm: k=2
                s.criar_fichas(k,turno,'eminência')
            if n=='Emeritus of Woe': s.preparado_emeritus=True
            if n=='Voldaren Epicure': s.drenar(3)
            if n=='Vampire Socialite' and s.atacou:
                for c in s.cri:
                    if c['v'] and c['n']!=n: c['cnt']+=1
        else:
            if n in ('Demonic Tutor','Vampiric Tutor'): s.tutor(n=='Vampiric Tutor')
            elif n=="Legion's Landing": s.criar_fichas(1,turno,'landing'); s.perm.add(n)
            elif n=='Pact of the Serpent':
                v=sum(1 for c in s.cri if c['v']); s.draw(v)
            elif n=='Deadly Dispute':
                s.sacrificar(turno); s.draw(2); s.tesouro+=1
            elif n=='Smothering Tithe': s.tithe=True; s.perm.add(n)
            elif n=='Banner of Kinship': s.banner=sum(1 for c in s.cri if c['v']); s.perm.add(n)
            elif n=='March of the Canonized':
                s.criar_fichas(max(0,s.xm),turno,'march')
            else: s.perm.add(n)
    def tutor(s,topo):
        for alvo in CFG["tutor"]:
            if alvo in s.lib:
                s.lib.remove(alvo)
                if topo: s.topo.append(alvo)
                else: s.hand.append(alvo)
                s.p(f"   busca {alvo}"); return
    def sacrificar(s,turno):
        fichas=[c for c in s.cri if c['tok']]
        if not fichas: return False
        s.cri.remove(fichas[0]); s.morte(turno); return True
    def morte(s,turno):
        s.morreu_turno+=1
        if 'Cordial Vampire' in s.perm:
            for c in s.cri:
                if c['v']: c['cnt']+=1
        if 'Cruel Celebrant' in s.perm: s.drenar(3)
        if 'Blood Artist' in s.perm: s.drenar(1)
        if 'Edgar, Ancient Bloodlord' in s.perm: s.ganhou_vida=True
    def drenar(s,x):
        if 'Bloodletter of Aclazotz' in s.perm: x*=2
        s.dano+=x
    def lordes(s,c):
        b=0
        for L in LORDS:
            if L in s.perm and c['n']!=L: b+=1
        if s.keeper_lord and c['n']!='Bloodline Keeper': b+=2
        b+=s.banner if 'Banner of Kinship' in s.perm else 0
        return b
    # ---------- turno ----------
    def turno(s,t):
        s.fichas_turno=0; s.baron_usado=False; s.atacou=False; s.morreu_turno=0; s.ganhou_vida=False
        for l in s.lands: l[1]=False
        for c in s.cri: c['sick']=False
        if s.tithe: s.tesouro+=2
        if 'Black Market Connections' in s.perm: s.tesouro+=1
        if t>1 and 'Necropotence' not in s.perm: s.draw(1)
        if "Bolas's Citadel" in s.perm: s.draw(1)
        s.jogar_terreno(t)
        F=s.fontes(t)
        def mana_livre(): return len(F)
        def tentar(n):
            nonlocal F
            pips,gen=custo(n)
            if n=='March of the Canonized':
                s.xm=max(0,len(F)-2); gen+=s.xm
            u=s.pagar(F,pips,gen,eh_vamp(n) and D[n]['tipo']=='C')
            if u is None: return False
            s.tesouro-=sum(1 for i in u if F[i][0]=='T')
            F=[f for i,f in enumerate(F) if i not in u]
            s.conjurar(n,t); return True
        def gastar(k):
            nonlocal F
            if len(F)<k: return False
            F.sort(key=lambda f:(f[0]=='T', 0 if f[0] in ('C','V') else len(f)))
            s.tesouro-=sum(1 for f in F[:k] if f[0]=='T'); F=F[k:]; return True
        # 1) Edgar a partir do turno 4, se der
        if not s.edgar and t>=4:
            s.hand.append('Edgar Markov')
            if not tentar('Edgar Markov'): s.hand.remove('Edgar Markov')
        # 2) prioridades
        for n in PRI_PRE:
            if n in s.hand: tentar(n)
        # 3) Vampiros e o resto, do mais barato
        for _ in range(12):
            op=[x for x in s.hand if D[x]['tipo']!='L' and x not in SEM_ALVO]
            op.sort(key=lambda x:(0 if eh_vamp(x) else 1, D[x]['mv']))
            feito=False
            for n in op:
                if n=='Pact of the Serpent' and sum(1 for c in s.cri if c['v'])<5: continue
                if n=='Deadly Dispute' and not any(c['tok'] for c in s.cri): continue
                if tentar(n): feito=True; break
            if not feito: break
        # Bloodline Keeper: transforma e faz ficha
        if 'Bloodline Keeper' in s.perm:
            if not s.keeper_lord and sum(1 for c in s.cri if c['v'])>=5 and gastar(1): s.keeper_lord=True
            s.cri.append(dict(n='ficha',pw=2,v=True,sick=True,cnt=0,ll=False,tok=True))
        # Kindred Charge antes do combate
        copias=[]
        if 'Kindred Charge' in s.hand and sum(1 for c in s.cri if c['v'])>=6:
            if tentar('Kindred Charge'):
                copias=[dict(n='cópia',pw=c['pw'],v=True,sick=False,cnt=0,ll=False,tok=True) for c in s.cri if c['v']]
        # ---------- combate ----------
        atac=[c for c in s.cri if not c['sick']]+copias
        if atac:
            s.atacou=True
            mult=(2 if 'Isshin, Two Heavens as One' in s.perm else 1)
            if s.edgar:
                k=mult*(2 if 'Roaming Throne' in s.perm else 1)
                for c in s.cri:
                    if c['v']: c['cnt']+=k
            av=[c for c in atac if c['v']]
            if 'Sanctum Seeker' in s.perm and 'Bloodletter of Aclazotz' in s.perm and len(av)>=8 and s.linha is None: s.linha=t
            if 'Sanctum Seeker' in s.perm and 'Bloodletter of Aclazotz' in s.perm and 'Isshin, Two Heavens as One' in s.perm and len(av)>=5 and s.linha_i is None: s.linha_i=t
            if 'Sanctum Seeker' in s.perm:
                k=mult*(2 if 'Roaming Throne' in s.perm else 1)
                s.drenar(3*k*len(av))
            if 'Mavren Fein, Dusk Apostle' in s.perm and any(c['v'] and not c['tok'] for c in atac):
                s.criar_fichas(mult*(2 if 'Roaming Throne' in s.perm else 1),t,'mavren')
            if 'Preacher of the Schism' in s.perm and any(c['n']=='Preacher of the Schism' for c in atac):
                k=mult*(2 if 'Roaming Throne' in s.perm else 1); s.criar_fichas(k,t,'preacher'); s.draw(k)
            sa=('Shared Animosity' in s.perm)
            coat=('Coat of Arms' in s.perm)
            nv=sum(1 for c in s.cri if c['v'])+len(copias)
            ds=False
            if "Akroma's Will" in s.hand and len(av)>=5:
                u=s.pagar(F,{'W':1,'B':0,'R':0},3,False)
                if u is not None:
                    s.tesouro-=sum(1 for i in u if F[i][0]=='T'); F=[f for i,f in enumerate(F) if i not in u]
                    s.hand.remove("Akroma's Will"); ds=True; s.p(f"T{t} Akroma's Will")
            vito_ll=False
            if 'Vito, Thorn of the Dusk Rose' in s.perm and len(av)>=6:
                u=s.pagar(F,{'W':0,'B':2,'R':0},3,False)
                if u is not None:
                    s.tesouro-=sum(1 for i in u if F[i][0]=='T'); F=[f for i,f in enumerate(F) if i not in u]; vito_ll=True
            X=0
            if 'Mirror Entity' in s.perm and len(F)>0:
                ganho_me=sum(max(0,len(F)-c['pw']) for c in atac)*(2 if 'Bloodletter of Aclazotz' in s.perm else 1)
                ganho_ex=(3*max(0,len(F)-2)*(2 if 'Bloodletter of Aclazotz' in s.perm else 1)) if 'Stensian Sanguinist' in s.perm else 0
                if ganho_me>ganho_ex:
                    X=len(F); s.tesouro-=sum(1 for f in F if f[0]=='T'); F=[]
            if 'Vampire Nocturnus' in s.perm:
                topo=s.lib[-1] if s.lib else None
                noct=2 if topo and custo(topo)[0]['B']>0 else 0
            else: noct=0
            tot=0
            for c in atac:
                base=max(c['pw'],X) if X else c['pw']
                p=base+c['cnt']+(s.lordes(c) if c['v'] else 0)+(noct if c['v'] else 0)
                if sa and c['v']: p+=mult*(len(av)-1)
                if coat and c['v']: p+=nv-1
                tot+=max(0,p)
                if c['ll']: s.ganhou_vida=True
            if ds: tot*=2
            if vito_ll: tot*=2
            if 'Bloodletter of Aclazotz' in s.perm: tot*=2
            s.dano+=tot; s.p(f"T{t} ataque: {len(atac)} atacantes, {tot} de dano; mesa {s.dano}")
        # ---------- segunda fase principal ----------
        if 'Vampire Socialite' in s.hand: tentar('Vampire Socialite')
        if 'Stensian Sanguinist' in s.perm and s.atacou and len(F)>=3:
            u=s.pagar(F,{'W':0,'B':2,'R':0},0,False)
            if u is not None:
                x=len(F)-2; s.drenar(3*x); s.tesouro=0; F=[]; s.p(f"T{t} Exsanguinate X={x}")
        sobra=len(F)
        if 'Scheming Silvertongue' in s.perm and s.ganhou_vida and sobra>=2: s.draw(2); sobra-=2
        if s.preparado_emeritus and 'Emeritus of Woe' in s.perm and sobra>=2: s.tutor(False); sobra-=2; s.preparado_emeritus=False
        if 'Indulgent Aristocrat' in s.perm and sobra>=2 and sum(1 for c in s.cri if c['v'])>=5 and not s.combo:
            if s.sacrificar(t):
                for c in s.cri:
                    if c['v']: c['cnt']+=1
                sobra-=2
        if 'Skullclamp' in s.perm:
            lord=any(L in s.perm for L in LORDS) or s.keeper_lord
            ok=(not lord) or ('Yahenni, Undying Partisan' in s.perm)
            k=0
            while ok and sobra>=1 and k<3 and sum(1 for c in s.cri if c['tok'])>3:
                s.sacrificar(t); s.draw(2); sobra-=1; k+=1
        if 'Welcoming Vampire' in s.perm and s.fichas_turno: s.draw(2 if 'Roaming Throne' in s.perm else 1)
        if 'Idol of Oblivion' in s.perm and s.fichas_turno: s.draw(1)
        if 'Florian, Voldaren Scion' in s.perm and s.atacou: s.draw(1)
        if 'Necropotence' in s.perm: s.draw(3)
        if 'Emeritus of Woe' in s.perm and s.morreu_turno>=2: s.preparado_emeritus=True
        # combo de reserva
        if 'Vito, Thorn of the Dusk Rose' in s.perm and 'Bloodthirsty Conqueror' in s.perm and s.combo is None:
            if any(c['ll'] for c in s.cri) or len(s.fontes(t))>=5: s.combo=t
        if s.kill is None and (s.dano>=120 or s.combo is not None): s.kill=t
        s.vamps_fim=sum(1 for c in s.cri if c['v'])
        # descarte até 7
        while len(s.hand)>7:
            s.hand.sort(key=lambda x:(D[x]['tipo']!='L',D[x]['mv'])); s.hand.pop(0)
def rodar(deck,N=20000,seed0=1,turnos=10):
    R=dict(v4=[],v4_8=0,edgar6=0,edgar_t=[],kill=[],k7=0,k8=0,vistas6=[],combo8=0,lin8=0,lini8=0)
    for i in range(N):
        g=Jogo(deck,seed0+i); g.preparado_emeritus=False; g.xm=0
        for t in range(1,turnos+1):
            g.turno(t)
            if t==4: R['v4'].append(g.vamps_fim); R['v4_8']+=g.vamps_fim>=8
            if t==6: R['vistas6'].append(g.vistas)
        if g.edgar_t and g.edgar_t<=6: R['edgar6']+=1
        R['edgar_t'].append(g.edgar_t or 99)
        R['kill'].append(g.kill or 99)
        R['k7']+= (g.kill or 99)<=7; R['k8']+=(g.kill or 99)<=8
        R['combo8']+= (g.combo or 99)<=8
        R['lin8']+=(g.linha or 99)<=8; R['lini8']+=(g.linha_i or 99)<=8
    return dict(vampiros_t4=statistics.mean(R['v4']),p_8vamp_t4=R['v4_8']/N,p_edgar_t6=R['edgar6']/N,
                edgar_mediana=statistics.median(R['edgar_t']),relogio_mediana=statistics.median(R['kill']),
                p_mesa_t7=R['k7']/N,p_mesa_t8=R['k8']/N,cartas_vistas_t6=statistics.mean(R['vistas6']),p_combo_t8=R['combo8']/N,p_linha_t8=R['lin8']/N,p_linha_isshin_t8=R['lini8']/N)
CFG['tutor']=TUTOR_PRI
